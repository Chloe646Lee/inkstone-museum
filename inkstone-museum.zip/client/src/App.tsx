import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import ExhibitionHall from "./pages/ExhibitionHall";
import ArtifactDetail from "./pages/ArtifactDetail";
import History from "./pages/History";
import Craft from "./pages/Craft";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/exhibition"} component={ExhibitionHall} />
      <Route path={"/artifact/:id"} component={ArtifactDetail} />
      <Route path={"/history"} component={History} />
      <Route path={"/craft"} component={Craft} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
