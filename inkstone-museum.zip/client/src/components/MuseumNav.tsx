/*
 * MuseumNav — 博物馆顶部导航栏
 * Design: Fixed dark navigation with gold accents, museum-style typography
 * 「紫石凝英」博物馆典藏美学
 */

import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";

const navLinks = [
  { href: "/", label: "首页", en: "Home" },
  { href: "/exhibition", label: "展览大厅", en: "Exhibition" },
  { href: "/history", label: "砚史溯源", en: "History" },
  { href: "/craft", label: "制砚工艺", en: "Craft" },
];

export default function MuseumNav() {
  const [location] = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        background: scrolled
          ? "rgba(15, 14, 12, 0.95)"
          : "rgba(15, 14, 12, 0.6)",
        backdropFilter: "blur(12px)",
        borderBottom: scrolled
          ? "1px solid rgba(201, 168, 76, 0.2)"
          : "1px solid transparent",
      }}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center gap-3 group cursor-pointer">
              <div
                className="w-8 h-8 flex items-center justify-center"
                style={{
                  border: "1px solid rgba(201, 168, 76, 0.5)",
                  background: "rgba(201, 168, 76, 0.08)",
                }}
              >
                <span
                  style={{
                    fontFamily: "'Noto Serif SC', serif",
                    color: "#C9A84C",
                    fontSize: "14px",
                    fontWeight: 600,
                  }}
                >
                  砚
                </span>
              </div>
              <div>
                <div
                  style={{
                    fontFamily: "'Noto Serif SC', serif",
                    fontSize: "13px",
                    fontWeight: 600,
                    color: "#EDE8DC",
                    letterSpacing: "0.1em",
                    lineHeight: 1.2,
                  }}
                >
                  砚台虚拟博物馆
                </div>
                <div
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "9px",
                    color: "#8A8278",
                    letterSpacing: "0.25em",
                    textTransform: "uppercase",
                  }}
                >
                  Inkstone Virtual Museum
                </div>
              </div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => {
              const isActive = location === link.href;
              return (
                <Link key={link.href} href={link.href}>
                  <div className="relative group cursor-pointer py-1">
                    <span
                      style={{
                        fontFamily: "'Noto Sans SC', sans-serif",
                        fontSize: "13px",
                        fontWeight: isActive ? 500 : 400,
                        color: isActive ? "#C9A84C" : "#B0A898",
                        letterSpacing: "0.05em",
                        transition: "color 0.3s ease",
                      }}
                      className="group-hover:text-[#C9A84C]"
                    >
                      {link.label}
                    </span>
                    <div
                      className="absolute bottom-0 left-0 h-px transition-all duration-300"
                      style={{
                        background: "#C9A84C",
                        width: isActive ? "100%" : "0%",
                      }}
                    />
                    <div
                      className="absolute bottom-0 left-0 h-px transition-all duration-300 opacity-0 group-hover:opacity-100 group-hover:w-full"
                      style={{
                        background: "rgba(201, 168, 76, 0.5)",
                        width: "0%",
                      }}
                    />
                  </div>
                </Link>
              );
            })}
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMenuOpen(!menuOpen)}
            style={{ color: "#B0A898" }}
          >
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div
          className="md:hidden"
          style={{
            background: "rgba(15, 14, 12, 0.98)",
            borderTop: "1px solid rgba(201, 168, 76, 0.15)",
          }}
        >
          <div className="px-6 py-4 space-y-4">
            {navLinks.map((link) => {
              const isActive = location === link.href;
              return (
                <Link key={link.href} href={link.href}>
                  <div
                    className="block py-2 cursor-pointer"
                    onClick={() => setMenuOpen(false)}
                    style={{
                      fontFamily: "'Noto Sans SC', sans-serif",
                      fontSize: "14px",
                      color: isActive ? "#C9A84C" : "#B0A898",
                      borderBottom: "1px solid rgba(201, 168, 76, 0.1)",
                    }}
                  >
                    {link.label}
                    <span
                      style={{
                        marginLeft: "8px",
                        fontSize: "11px",
                        color: "#5A5248",
                        fontFamily: "'Playfair Display', serif",
                      }}
                    >
                      {link.en}
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </nav>
  );
}
