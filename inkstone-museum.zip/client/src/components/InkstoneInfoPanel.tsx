/*
 * InkstoneInfoPanel — 砚台信息展示面板
 * 「紫石凝英」— 展示砚台的详细介绍、历史背景、特征等
 */

import React from 'react';
import { Inkstone } from '@/data/inkstones';

interface InkstonePanelProps {
  inkstone: Inkstone;
}

export const InkstoneInfoPanel: React.FC<InkstonePanelProps> = ({ inkstone }) => {
  return (
    <div
      className="w-full mt-8"
      style={{
        background: 'linear-gradient(135deg, rgba(30, 28, 24, 0.8) 0%, rgba(20, 18, 16, 0.8) 100%)',
        border: '1px solid rgba(201, 168, 76, 0.15)',
        borderRadius: '8px',
        padding: '24px',
        backdropFilter: 'blur(10px)',
      }}
    >
      {/* 标题区域 */}
      <div className="mb-6 pb-6" style={{ borderBottom: '1px solid rgba(201, 168, 76, 0.1)' }}>
        <div className="flex items-center gap-3 mb-3">
          <div
            style={{
              width: '4px',
              height: '20px',
              background: '#C9A84C',
              borderRadius: '2px',
            }}
          />
          <h3
            style={{
              fontFamily: "'Noto Serif SC', serif",
              fontSize: '18px',
              fontWeight: 400,
              color: '#EDE8DC',
            }}
          >
            展品信息
          </h3>
        </div>
        <p
          style={{
            fontFamily: "'Noto Sans SC', sans-serif",
            fontSize: '12px',
            color: '#5A5248',
          }}
        >
          {inkstone.era} · {inkstone.origin}
        </p>
      </div>

      {/* 内容网格 */}
      <div className="grid md:grid-cols-2 gap-8 mb-8">
        {/* 左侧：基本信息 */}
        <div>
          <h4
            style={{
              fontFamily: "'Noto Serif SC', serif",
              fontSize: '14px',
              fontWeight: 500,
              color: '#C9A84C',
              marginBottom: '12px',
              textTransform: 'uppercase',
              letterSpacing: '1px',
            }}
          >
            基本信息
          </h4>
          <div className="space-y-4">
            {[
              { label: '名称', value: inkstone.name },
              { label: '英文名', value: inkstone.englishName },
              { label: '年代', value: inkstone.dynasty },
              { label: '产地', value: inkstone.origin },
              { label: '材质', value: inkstone.material },
              { label: '尺寸', value: inkstone.dimensions },
            ].map((item) => (
              <div key={item.label} className="flex gap-4">
                <span
                  style={{
                    fontFamily: "'Noto Sans SC', sans-serif",
                    fontSize: '12px',
                    color: '#5A5248',
                    minWidth: '60px',
                  }}
                >
                  {item.label}：
                </span>
                <span
                  style={{
                    fontFamily: "'Noto Sans SC', sans-serif",
                    fontSize: '12px',
                    color: '#B0A898',
                    flex: 1,
                  }}
                >
                  {item.value}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* 右侧：特征与分类 */}
        <div>
          <h4
            style={{
              fontFamily: "'Noto Serif SC', serif",
              fontSize: '14px',
              fontWeight: 500,
              color: '#C9A84C',
              marginBottom: '12px',
              textTransform: 'uppercase',
              letterSpacing: '1px',
            }}
          >
            特征与分类
          </h4>
          <div className="space-y-4">
            <div>
              <p
                style={{
                  fontFamily: "'Noto Sans SC', sans-serif",
                  fontSize: '11px',
                  color: '#5A5248',
                  marginBottom: '8px',
                  textTransform: 'uppercase',
                  letterSpacing: '0.5px',
                }}
              >
                分类
              </p>
              <span
                style={{
                  display: 'inline-block',
                  background: 'rgba(201, 168, 76, 0.1)',
                  border: '1px solid rgba(201, 168, 76, 0.25)',
                  padding: '4px 12px',
                  fontSize: '11px',
                  color: '#C9A84C',
                  fontFamily: "'Noto Sans SC', sans-serif",
                  borderRadius: '4px',
                }}
              >
                {inkstone.category}
              </span>
            </div>

            <div>
              <p
                style={{
                  fontFamily: "'Noto Sans SC', sans-serif",
                  fontSize: '11px',
                  color: '#5A5248',
                  marginBottom: '8px',
                  textTransform: 'uppercase',
                  letterSpacing: '0.5px',
                }}
              >
                石品特征
              </p>
              <div className="flex flex-wrap gap-2">
                {inkstone.characteristics.map((char, idx) => (
                  <span
                    key={idx}
                    style={{
                      display: 'inline-block',
                      background: 'rgba(201, 168, 76, 0.05)',
                      border: '1px solid rgba(201, 168, 76, 0.15)',
                      padding: '4px 10px',
                      fontSize: '11px',
                      color: '#8A8278',
                      fontFamily: "'Noto Sans SC', sans-serif",
                      borderRadius: '4px',
                    }}
                  >
                    {char}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 描述区域 */}
      <div className="mb-8 pb-8" style={{ borderBottom: '1px solid rgba(201, 168, 76, 0.1)' }}>
        <h4
          style={{
            fontFamily: "'Noto Serif SC', serif",
            fontSize: '14px',
            fontWeight: 500,
            color: '#C9A84C',
            marginBottom: '12px',
            textTransform: 'uppercase',
            letterSpacing: '1px',
          }}
        >
          展品介绍
        </h4>
        <p
          style={{
            fontFamily: "'Noto Sans SC', sans-serif",
            fontSize: '13px',
            lineHeight: 1.8,
            color: '#B0A898',
            marginBottom: '12px',
          }}
        >
          {inkstone.description}
        </p>
        <p
          style={{
            fontFamily: "'Noto Sans SC', sans-serif",
            fontSize: '12px',
            lineHeight: 1.8,
            color: '#8A8278',
          }}
        >
          {inkstone.longDescription}
        </p>
      </div>

      {/* 历代题铭区域 */}
      <div
        style={{
          borderLeft: '3px solid rgba(201, 168, 76, 0.3)',
          paddingLeft: '16px',
          paddingTop: '8px',
          paddingBottom: '8px',
        }}
      >
        <h4
          style={{
            fontFamily: "'Noto Serif SC', serif",
            fontSize: '14px',
            fontWeight: 500,
            color: '#C9A84C',
            marginBottom: '12px',
            textTransform: 'uppercase',
            letterSpacing: '1px',
          }}
        >
          历代题铭
        </h4>
        <p
          style={{
            fontFamily: "'Noto Serif SC', serif",
            fontSize: '14px',
            lineHeight: 1.8,
            color: '#C9A84C',
            fontStyle: 'italic',
            marginBottom: '12px',
          }}
        >
          "{inkstone.quote}"
        </p>
        <p
          style={{
            fontFamily: "'Noto Sans SC', sans-serif",
            fontSize: '11px',
            color: '#5A5248',
            textAlign: 'right',
            textTransform: 'uppercase',
            letterSpacing: '0.5px',
          }}
        >
          —— {inkstone.quoteAuthor}
        </p>
      </div>
    </div>
  );
};

export default InkstoneInfoPanel;
