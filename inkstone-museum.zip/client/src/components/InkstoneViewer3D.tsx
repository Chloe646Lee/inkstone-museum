/*
 * 砚台 3D 查看器组件
 * 「紫石凝英」— 360° 旋转展示
 * 支持鼠标拖拽旋转、自动旋转、缩放等交互
 */

import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';

interface InkstoneViewer3DProps {
  modelUrl?: string;
  inkstoneId: string;
  inkstoneColor?: string;
}

/**
 * 生成程序化的砚台 3D 模型
 * 使用 Three.js 基础几何体组合而成
 */
function createInkstoneGeometry(color: string) {
  const group = new THREE.Group();

  // 砚台主体 - 椭圆形盘
  const baseGeometry = new THREE.LatheGeometry(
    [
      new THREE.Vector2(0, 0),
      new THREE.Vector2(1.2, 0),
      new THREE.Vector2(1.3, 0.1),
      new THREE.Vector2(1.3, 0.3),
      new THREE.Vector2(1.1, 0.4),
      new THREE.Vector2(0.8, 0.35),
      new THREE.Vector2(0.5, 0.3),
      new THREE.Vector2(0.3, 0.25),
      new THREE.Vector2(0.1, 0.2),
      new THREE.Vector2(0, 0.15),
    ],
    32
  );

  const baseMaterial = new THREE.MeshPhongMaterial({
    color: color,
    shininess: 100,
    side: THREE.DoubleSide,
  });

  const baseMesh = new THREE.Mesh(baseGeometry, baseMaterial);
  baseMesh.scale.set(1, 0.6, 1);
  group.add(baseMesh);

  // 砚堂（研墨区域）- 内凹圆形
  const inkPoolGeometry = new THREE.CylinderGeometry(0.6, 0.7, 0.1, 32);
  const inkPoolMaterial = new THREE.MeshPhongMaterial({
    color: new THREE.Color(color).multiplyScalar(0.7),
    shininess: 80,
  });
  const inkPool = new THREE.Mesh(inkPoolGeometry, inkPoolMaterial);
  inkPool.position.y = 0.25;
  group.add(inkPool);

  // 砚边装饰 - 浮雕纹理（使用小球组成）
  const decorationColor = new THREE.Color(color).multiplyScalar(1.2);
  for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2;
    const x = Math.cos(angle) * 1.1;
    const z = Math.sin(angle) * 1.1;

    const decorGeometry = new THREE.SphereGeometry(0.08, 16, 16);
    const decorMaterial = new THREE.MeshPhongMaterial({
      color: decorationColor,
      shininess: 60,
    });
    const decor = new THREE.Mesh(decorGeometry, decorMaterial);
    decor.position.set(x, 0.35, z);
    group.add(decor);
  }

  // 砚足 - 三足设计
  for (let i = 0; i < 3; i++) {
    const angle = (i / 3) * Math.PI * 2;
    const x = Math.cos(angle) * 0.8;
    const z = Math.sin(angle) * 0.8;

    const footGeometry = new THREE.CylinderGeometry(0.05, 0.08, 0.15, 16);
    const footMaterial = new THREE.MeshPhongMaterial({
      color: new THREE.Color(color).multiplyScalar(0.8),
      shininess: 70,
    });
    const foot = new THREE.Mesh(footGeometry, footMaterial);
    foot.position.set(x, -0.15, z);
    group.add(foot);
  }

  return group;
}

export const InkstoneViewer3D: React.FC<InkstoneViewer3DProps> = ({
  modelUrl,
  inkstoneId,
  inkstoneColor = '#4A3050',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const modelRef = useRef<THREE.Group | null>(null);
  const [isAutoRotate, setIsAutoRotate] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const [previousMousePosition, setPreviousMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (!containerRef.current) return;

    // 场景设置
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f0e0c);
    sceneRef.current = scene;

    // 相机设置
    const camera = new THREE.PerspectiveCamera(
      75,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.set(0, 0.5, 2.5);
    cameraRef.current = camera;

    // 渲染器设置
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true;
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 灯光设置 - 博物馆聚光灯效果
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    const spotLight = new THREE.SpotLight(0xffffff, 1.5);
    spotLight.position.set(3, 3, 3);
    spotLight.castShadow = true;
    spotLight.shadow.mapSize.width = 2048;
    spotLight.shadow.mapSize.height = 2048;
    scene.add(spotLight);

    const backLight = new THREE.PointLight(0xc9a84c, 0.8);
    backLight.position.set(-2, 1, -2);
    scene.add(backLight);

    // 创建砚台模型
    const inkstone = createInkstoneGeometry(inkstoneColor);
    scene.add(inkstone);
    modelRef.current = inkstone;

    // 鼠标交互
    const onMouseDown = (e: MouseEvent) => {
      setIsDragging(true);
      setPreviousMousePosition({ x: e.clientX, y: e.clientY });
      setIsAutoRotate(false);
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging || !modelRef.current) return;

      const deltaX = e.clientX - previousMousePosition.x;
      const deltaY = e.clientY - previousMousePosition.y;

      modelRef.current.rotation.y += deltaX * 0.01;
      modelRef.current.rotation.x += deltaY * 0.01;

      setPreviousMousePosition({ x: e.clientX, y: e.clientY });
    };

    const onMouseUp = () => {
      setIsDragging(false);
      setIsAutoRotate(true);
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const zoomSpeed = 0.1;
      if (e.deltaY > 0) {
        camera.position.z += zoomSpeed;
      } else {
        camera.position.z -= zoomSpeed;
      }
      camera.position.z = Math.max(1, Math.min(5, camera.position.z));
    };

    renderer.domElement.addEventListener('mousedown', onMouseDown);
    renderer.domElement.addEventListener('mousemove', onMouseMove);
    renderer.domElement.addEventListener('mouseup', onMouseUp);
    renderer.domElement.addEventListener('wheel', onWheel, { passive: false });

    // 处理窗口大小变化
    const handleResize = () => {
      if (!containerRef.current) return;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    // 动画循环
    const animate = () => {
      requestAnimationFrame(animate);

      if (isAutoRotate && modelRef.current && !isDragging) {
        modelRef.current.rotation.y += 0.005;
      }

      renderer.render(scene, camera);
    };

    animate();

    // 清理
    return () => {
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('mousedown', onMouseDown);
      renderer.domElement.removeEventListener('mousemove', onMouseMove);
      renderer.domElement.removeEventListener('mouseup', onMouseUp);
      renderer.domElement.removeEventListener('wheel', onWheel);
      renderer.dispose();
      if (containerRef.current && renderer.domElement.parentNode === containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  // 处理拖拽状态变化
  useEffect(() => {
    if (!isDragging) {
      setPreviousMousePosition({ x: 0, y: 0 });
    }
  }, [isDragging]);

  return (
    <div className="w-full h-full flex flex-col">
      <div
        ref={containerRef}
        className="flex-1 relative bg-gradient-to-b from-[#1E1C18] to-[#0F0E0C] rounded-lg overflow-hidden"
        style={{ minHeight: '500px' }}
      />
      <div className="mt-4 flex items-center justify-center gap-4 text-sm text-[#B0A898]">
        <span className="flex items-center gap-2">
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
            <path
              fillRule="evenodd"
              d="M10 18a8 8 0 100-16 8 8 0 000 16zm0-2a6 6 0 100-12 6 6 0 000 12z"
            />
          </svg>
          拖拽旋转
        </span>
        <span className="flex items-center gap-2">
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
          </svg>
          滚轮缩放
        </span>
        {isAutoRotate && (
          <span className="flex items-center gap-2 text-[#C9A84C]">
            <svg className="w-4 h-4 animate-spin" fill="currentColor" viewBox="0 0 20 20">
              <path
                fillRule="evenodd"
                d="M4.293 5.293a1 1 0 011.414 0L10 9.586l4.293-4.293a1 1 0 111.414 1.414L11.414 11l4.293 4.293a1 1 0 01-1.414 1.414L10 12.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 11 4.293 6.707a1 1 0 010-1.414z"
                clipRule="evenodd"
              />
            </svg>
            自动旋转中
          </span>
        )}
      </div>
    </div>
  );
};

export default InkstoneViewer3D;
