/*
 * FavoriteShareButtons — 收藏与分享按钮组件
 * 「紫石凝英」— 用户互动功能
 */

import React, { useState } from 'react';
import { Heart, Share2, Copy, Check } from 'lucide-react';
import { Inkstone } from '@/data/inkstones';

interface FavoriteShareButtonsProps {
  inkstone: Inkstone;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}

export const FavoriteShareButtons: React.FC<FavoriteShareButtonsProps> = ({
  inkstone,
  isFavorite,
  onToggleFavorite,
}) => {
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);

  // 生成分享链接
  const shareUrl = `${window.location.origin}/artifact/${inkstone.id}`;
  const shareText = `我在砚台虚拟博物馆发现了一件精美的展品：${inkstone.name}（${inkstone.englishName}）。来欣赏这件${inkstone.era}的${inkstone.category}吧！`;

  // 复制链接到剪贴板
  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (error) {
      console.error('Failed to copy link:', error);
    }
  };

  // 分享到微信（生成二维码提示）
  const handleShareWeChat = () => {
    alert(`请扫描以下链接的二维码分享给微信好友：\n${shareUrl}`);
  };

  // 分享到微博
  const handleShareWeibo = () => {
    const weiboUrl = `https://service.weibo.com/share/share.php?url=${encodeURIComponent(shareUrl)}&title=${encodeURIComponent(shareText)}`;
    window.open(weiboUrl, '_blank');
  };

  // 分享到 QQ
  const handleShareQQ = () => {
    const qqUrl = `https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=${encodeURIComponent(shareUrl)}&title=${encodeURIComponent(shareText)}`;
    window.open(qqUrl, '_blank');
  };

  return (
    <div className="flex items-center gap-3">
      {/* 收藏按钮 */}
      <button
        onClick={onToggleFavorite}
        className="flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300"
        style={{
          background: isFavorite
            ? 'rgba(201, 168, 76, 0.15)'
            : 'rgba(201, 168, 76, 0.05)',
          border: `1px solid ${isFavorite ? 'rgba(201, 168, 76, 0.4)' : 'rgba(201, 168, 76, 0.15)'}`,
          color: isFavorite ? '#C9A84C' : '#8A8278',
        }}
        title={isFavorite ? '取消收藏' : '收藏此砚台'}
      >
        <Heart
          size={18}
          fill={isFavorite ? 'currentColor' : 'none'}
          style={{
            transition: 'all 0.3s ease',
            transform: isFavorite ? 'scale(1.1)' : 'scale(1)',
          }}
        />
        <span
          style={{
            fontFamily: "'Noto Sans SC', sans-serif",
            fontSize: '13px',
            fontWeight: 500,
          }}
        >
          {isFavorite ? '已收藏' : '收藏'}
        </span>
      </button>

      {/* 分享按钮 */}
      <div className="relative">
        <button
          onClick={() => setShowShareMenu(!showShareMenu)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300"
          style={{
            background: 'rgba(201, 168, 76, 0.05)',
            border: '1px solid rgba(201, 168, 76, 0.15)',
            color: '#8A8278',
          }}
          title="分享此砚台"
        >
          <Share2 size={18} />
          <span
            style={{
              fontFamily: "'Noto Sans SC', sans-serif",
              fontSize: '13px',
              fontWeight: 500,
            }}
          >
            分享
          </span>
        </button>

        {/* 分享菜单 */}
        {showShareMenu && (
          <div
            className="absolute top-full right-0 mt-2 rounded-lg shadow-lg z-50"
            style={{
              background: 'rgba(20, 18, 16, 0.95)',
              border: '1px solid rgba(201, 168, 76, 0.2)',
              backdropFilter: 'blur(10px)',
              minWidth: '180px',
            }}
          >
            {/* 复制链接 */}
            <button
              onClick={handleCopyLink}
              className="w-full text-left px-4 py-3 flex items-center gap-3 hover:bg-white/5 transition-colors first:rounded-t-lg"
              style={{
                color: copySuccess ? '#C9A84C' : '#B0A898',
                borderBottom: '1px solid rgba(201, 168, 76, 0.1)',
              }}
            >
              {copySuccess ? (
                <>
                  <Check size={16} />
                  <span
                    style={{
                      fontFamily: "'Noto Sans SC', sans-serif",
                      fontSize: '12px',
                    }}
                  >
                    已复制
                  </span>
                </>
              ) : (
                <>
                  <Copy size={16} />
                  <span
                    style={{
                      fontFamily: "'Noto Sans SC', sans-serif",
                      fontSize: '12px',
                    }}
                  >
                    复制链接
                  </span>
                </>
              )}
            </button>

            {/* 分享到微信 */}
            <button
              onClick={handleShareWeChat}
              className="w-full text-left px-4 py-3 hover:bg-white/5 transition-colors"
              style={{
                color: '#B0A898',
                borderBottom: '1px solid rgba(201, 168, 76, 0.1)',
                fontFamily: "'Noto Sans SC', sans-serif",
                fontSize: '12px',
              }}
            >
              分享到微信
            </button>

            {/* 分享到微博 */}
            <button
              onClick={handleShareWeibo}
              className="w-full text-left px-4 py-3 hover:bg-white/5 transition-colors"
              style={{
                color: '#B0A898',
                borderBottom: '1px solid rgba(201, 168, 76, 0.1)',
                fontFamily: "'Noto Sans SC', sans-serif",
                fontSize: '12px',
              }}
            >
              分享到微博
            </button>

            {/* 分享到 QQ */}
            <button
              onClick={handleShareQQ}
              className="w-full text-left px-4 py-3 hover:bg-white/5 transition-colors last:rounded-b-lg"
              style={{
                color: '#B0A898',
                fontFamily: "'Noto Sans SC', sans-serif",
                fontSize: '12px',
              }}
            >
              分享到 QQ
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default FavoriteShareButtons;
