/*
 * useFavorites — 收藏管理 Hook
 * 使用 localStorage 存储用户收藏的砚台
 */

import { useState, useEffect } from 'react';

const FAVORITES_KEY = 'inkstone-favorites';

export function useFavorites() {
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [isLoaded, setIsLoaded] = useState(false);

  // 从 localStorage 加载收藏列表
  useEffect(() => {
    try {
      const stored = localStorage.getItem(FAVORITES_KEY);
      if (stored) {
        setFavorites(new Set(JSON.parse(stored)));
      }
    } catch (error) {
      console.error('Failed to load favorites:', error);
    }
    setIsLoaded(true);
  }, []);

  // 保存收藏列表到 localStorage
  const saveFavorites = (newFavorites: Set<string>) => {
    try {
      localStorage.setItem(FAVORITES_KEY, JSON.stringify(Array.from(newFavorites)));
    } catch (error) {
      console.error('Failed to save favorites:', error);
    }
  };

  // 切换收藏状态
  const toggleFavorite = (id: string) => {
    const newFavorites = new Set(favorites);
    if (newFavorites.has(id)) {
      newFavorites.delete(id);
    } else {
      newFavorites.add(id);
    }
    setFavorites(newFavorites);
    saveFavorites(newFavorites);
  };

  // 检查是否已收藏
  const isFavorite = (id: string) => favorites.has(id);

  return {
    favorites,
    isLoaded,
    toggleFavorite,
    isFavorite,
  };
}
