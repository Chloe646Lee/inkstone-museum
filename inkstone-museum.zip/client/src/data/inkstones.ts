// 砚台虚拟博物馆 — 展品数据
// 「紫石凝英」博物馆典藏美学

export interface Inkstone {
  id: string;
  catalogNumber: string;
  name: string;
  englishName: string;
  dynasty: string;
  origin: string;
  material: string;
  dimensions: string;
  description: string;
  longDescription: string;
  characteristics: string[];
  quote: string;
  quoteAuthor: string;
  imageUrl: string;
  accentColor: string;
  category: "四大名砚" | "历代名砚" | "文人砚";
  era: string;
  featured: boolean;
  modelColor: string; // 3D 模型颜色
  modelScale?: number; // 3D 模型缩放比例
}

export const HERO_BANNER_URL =
  "https://private-us-east-1.manuscdn.com/sessionFile/0Ywg1OlIbPCyWeQ6vtOBWk/sandbox/S92i0Hciju4f3pB8DMCMus-img-1_1771964415000_na1fn_aGVyby1iYW5uZXI.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMFl3ZzFPbEliUEN5V2VRNnZ0T0JXay9zYW5kYm94L1M5MmkwSGNpanU0ZjNwQjhETUNNdXMtaW1nLTFfMTc3MTk2NDQxNTAwMF9uYTFmbl9hR1Z5YnkxaVlXNXVaWEkucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=UKwTnWXWmZPNPHQZjruDjUVfQ0BXb3AJYt1~Qdqm0ZY7yGTOie~uFoQf26hlhOJVqwY1zy3aTxtwjSRWkbdBT2etzfCUtQH4jYDwLF391v9RHaykT1nMTT1BmAZncz6YMUpRxWgkhH3BVwfLH-avZT7lmCH12WX~AT-NLeV5PCwZF8BqYr-r9hu-vkwgWgMmxGjgfqaOpxWIr2axo1x3YEK2U9axLkzgJn8ucpLpGh6-3QNrAZw4Y8dEygQAz2g-ga4FqI99HXS2bwZuDviH13YyyJkdjFtC9DIPOSZ5aVHy4sFoGa3x~E4i1Rls3A1Xb4Ndc7iOh25VsezC4OjDTg__";

export const MUSEUM_HALL_URL =
  "https://private-us-east-1.manuscdn.com/sessionFile/0Ywg1OlIbPCyWeQ6vtOBWk/sandbox/S92i0Hciju4f3pB8DMCMus-img-5_1771964415000_na1fn_bXVzZXVtLWhhbGw.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMFl3ZzFPbEliUEN5V2VRNnZ0T0JXay9zYW5kYm94L1M5MmkwSGNpanU0ZjNwQjhETUNNdXMtaW1nLTVfMTc3MTk2NDQxNTAwMF9uYTFmbl9iWFZ6WlhWdExXaGhiR3cucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=voOuNpURdvcR3pGxlSaRC0H4Kip3beALAnQRKHi-1oEaRXr~T2eNj1Fc-49KMeZORdvp4KNboBLniwzz5wO8Wxg2JImkn9~cM84Ap8FYc4OC~KGVN40El45q1j61l-GgVly-JorS9FwN~pxfeJth07m-nwNHRoSHCKmLlLXuBGRhLBeERRcNk4XXxUhpX4rslFaQJdjCnJKl-yhbChMS7BLgwqfU-mhANEJHm5~80qtrR~0LD4pGeyR6yhLJ~xkwv0axAf2oYM8Q~QsMkk1-RM~b7txxQLllcF6c0wSimQ40swj5vi3PFeppIzp1dG5Ghr8DrA~piEwxlN6yLHprMg__";

export const CRAFT_URL =
  "https://private-us-east-1.manuscdn.com/sessionFile/0Ywg1OlIbPCyWeQ6vtOBWk/sandbox/RW6cUbJAcRnDxjcdsv8y7A-img-2_1771964453000_na1fn_aW5rc3RvbmUtY3JhZnQ.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMFl3ZzFPbEliUEN5V2VRNnZ0T0JXay9zYW5kYm94L1JXNmNVYkpBY1JuRHhqY2Rzdjh5N0EtaW1nLTJfMTc3MTk2NDQ1MzAwMF9uYTFmbl9hVzVyYzNSdmJtVXRZM0poWm5RLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=JjJl69VDt6RB7o~e-MlVJnzIqbXf8Vlm2M0JbB6VuVqvQqnp97niXYbAkUUpk7SQtvJ-iqLSrtBIYQ~E2o6bG-MTaMS~Y9bk0ijP8O3QV-ZXPuDjEoILf-aVrHEj07orrYjvvJLSSORpsw-WXxKhMHjIbXAY1fuckzNEcfjjj6D0~b~ZaERqjTJPKIuHEy9pCphlNwfMsgEs6PqM9Faf4uPVRJbjNl3Rj-k6p7E-27rXOa3XgEDV0oUIiaBSPmOlS6wyTtaJl8BB~tGJpDK7Gj1RN9BjL3KIDs8cZRVxQR~fsKtRMC-uDI-ixbmqALEJHwe8pc~-PnXkbt7hZEAM86w__";

export const inkstones: Inkstone[] = [
  {
    id: "duan-001",
    catalogNumber: "YT-2024-001",
    name: "端砚·龙腾云海",
    englishName: "Duan Inkstone — Dragon Among Clouds",
    dynasty: "清代",
    origin: "广东肇庆端溪",
    material: "端溪老坑石",
    dimensions: "28 × 22 × 4.5 cm",
    description: "群砚之首，石质细腻温润，鱼脑冻天成",
    longDescription:
      "此砚取材于广东肇庆端溪老坑，石质细腻如婴儿肌肤，温润如玉。砚面中央可见天然形成的鱼脑冻石品，色白如云，为端砚中最珍贵的石品之一。砚边精雕游龙穿云纹饰，刀法遒劲，线条流畅，展现了清代匠人高超的雕刻技艺。此砚发墨细腻，研墨不费力，墨汁细腻均匀，历代文人墨客视为案头珍品。",
    characteristics: ["鱼脑冻石品", "龙云浮雕", "老坑石质", "发墨细腻"],
    quote: "端溪砚石，天下第一，其色紫，其质润，其声清，其纹美。",
    quoteAuthor: "苏轼《端砚铭》",
    imageUrl:
      "https://private-us-east-1.manuscdn.com/sessionFile/0Ywg1OlIbPCyWeQ6vtOBWk/sandbox/S92i0Hciju4f3pB8DMCMus-img-2_1771964410000_na1fn_ZHVhbi1pbmtzdG9uZQ.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMFl3ZzFPbEliUEN5V2VRNnZ0T0JXay9zYW5kYm94L1M5MmkwSGNpanU0ZjNwQjhETUNNdXMtaW1nLTJfMTc3MTk2NDQxMDAwMF9uYTFmbl9aSFZoYmkxcGJtdHpkRzl1WlEucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=VA80ZybHt4n93t9HRm8nqzW7jvJ~sa~OmjgBPNr8kh-w98FlSTHOpENYxS6w7voBfiFIFz3~Uxz5RJzbvbkqQcBU68pn27Z8gYd2kD7chlvYyfiMqiO4sWCZEROWNxsBBCuxwOK3qE2Apf1KZhQoe3yd7eja908m61Z4mVvPW9NJkdPeQQTfZ1mdNehHqzJ3uN7P1EKQsc3180Tnuw5Yodub8TC2-54gqFirqlpiJA2qiN80o1--hLiZuhOcgRv74qdtRSWhaFVOqLw0NQg9XqmwkF6V4Lt0Dg0vX4Vcf59k6Je9uzTBCfU~db2SR44s53ou8ig5NHsChNPuxnYK6g__",
    accentColor: "#4A3050",
    category: "四大名砚",
    era: "清代（1644–1912）",
    featured: true,
    modelColor: "#5D4E6D",
  },
  {
    id: "she-001",
    catalogNumber: "YT-2024-002",
    name: "歙砚·金晕波纹",
    englishName: "She Inkstone — Golden Wave Patterns",
    dynasty: "宋代",
    origin: "安徽歙县龙尾山",
    material: "龙尾石",
    dimensions: "24 × 16 × 3.5 cm",
    description: "色如碧云，声如金石，金晕天成，纹理精美",
    longDescription:
      "歙砚又称龙尾砚，产于安徽歙县龙尾山。此砚石色青黑，天然形成的金晕纹理如波涛涌动，极为罕见。砚面平整光滑，质地坚润，抚之如肌，磨之有锋。宋代文豪欧阳修、苏轼均对歙砚赞誉有加。此砚发墨细腻，墨汁浓稠，书写流畅，为历代书法家所珍视。砚背刻有宋代文人题铭，字迹清晰，书法精妙。",
    characteristics: ["金晕纹理", "龙尾石质", "声如金石", "宋代题铭"],
    quote: "歙石出龙尾，其质坚润，其色青黑，其纹金晕，天下之宝也。",
    quoteAuthor: "欧阳修《砚谱》",
    imageUrl:
      "https://private-us-east-1.manuscdn.com/sessionFile/0Ywg1OlIbPCyWeQ6vtOBWk/sandbox/S92i0Hciju4f3pB8DMCMus-img-3_1771964409000_na1fn_c2hlLWlua3N0b25l.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMFl3ZzFPbEliUEN5V2VRNnZ0T0JXay9zYW5kYm94L1M5MmkwSGNpanU0ZjNwQjhETUNNdXMtaW1nLTNfMTc3MTk2NDQwOTAwMF9uYTFmbl9jMmhsTFdsdWEzTjBiMjVsLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=Rf~AQVqygebnQ6Nr5~2lWYMfVooVQwp3VJNmpNv7vSyk1DnG5YXY-DEb~~4wUYb4L2qsHDSsSerOwKJoNecGGSrlq7cCXI15GE-OBJwd28~ZIdkkMlGGOcKDU4O~Gr386j95qGLa8lv9JYGHijIxDZRbfkuGHbCb2r0Fcr8ne765XXYE8DXdySa8u1Gq~C2hLvmzhRAbwssgI8XC8drjhPKEosi0RQ3Gzrl00iYzuHr1zq5EgrhcUBBij357T-6SPH-EReC-pypb84yqNePFp-MWJLrORyZgA1oZPbpoYHtY7~DZWK1kMt4kJu0FkqFQMYxxas4yQaGqswxRjdsO4g__",
    accentColor: "#2C3A4A",
    category: "四大名砚",
    era: "宋代（960–1279）",
    featured: true,
    modelColor: "#3A4A5A",
  },
  {
    id: "tao-001",
    catalogNumber: "YT-2024-003",
    name: "洮河砚·碧玉流云",
    englishName: "Tao River Inkstone — Jade Green Flowing Clouds",
    dynasty: "明代",
    origin: "甘肃洮河流域",
    material: "洮河绿石",
    dimensions: "20 × 15 × 3 cm",
    description: "碧绿如玉，纹理天成，洮河之宝，西北名砚",
    longDescription:
      "洮砚产于甘肃南部洮河流域，石色碧绿如玉，天然纹理如流云飞瀑，极具观赏价值。此砚石质细腻，温润如脂，发墨迅速，墨汁细腻。明代文人对洮砚评价极高，认为其石质仅次于端砚。砚面保留了石材天然的流云纹理，匠人仅略加修整，以展现洮河石材的天然之美。砚池深邃，储墨充足，为书法创作的理想用砚。",
    characteristics: ["碧绿石色", "天然流云纹", "发墨迅速", "温润如脂"],
    quote: "洮河石，色碧绿，质温润，纹如流云，西北之宝，可与端歙并称。",
    quoteAuthor: "高似孙《砚笺》",
    imageUrl:
      "https://private-us-east-1.manuscdn.com/sessionFile/0Ywg1OlIbPCyWeQ6vtOBWk/sandbox/S92i0Hciju4f3pB8DMCMus-img-4_1771964410000_na1fn_dGFvLWlua3N0b25l.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMFl3ZzFPbEliUEN5V2VRNnZ0T0JXay9zYW5kYm94L1M5MmkwSGNpanU0ZjNwQjhETUNNdXMtaW1nLTRfMTc3MTk2NDQxMDAwMF9uYTFmbl9kR0Z2TFdsdWEzTjBiMjVsLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=h-q-wKj0eGvJj0J2eGCBhEvFYaxqU2~bXdykLY8MvAs63ASYzOc0nzwDD2s~XOZy6E5wZclB1ZDNIJd-I~wrhTrgoNK78Emb16qbGenIRLfUvXuzwQ7JOG9lnGd2cGVdLe2Qs2r0MPf4-WRsjDWqStnpy6Jz0aW1mOTt7dtSC5ZeHmfT-hhYxPc0EGgTNmdM20a4jKPWmu4e93190ucG0XWMjvRqCu4uloro19JdMQUp4kDmfXfeWHBzAgqtvVh7bjl21w50EsbE-ePD4gHKjWuPr-gQS~k2T2XfU1rOtQjkom2xSwwPiVF45o6B497fUFIhNhbYInn3R1tz3dYIpA__",
    accentColor: "#1E3A2E",
    category: "四大名砚",
    era: "明代（1368–1644）",
    featured: true,
    modelColor: "#2A5A4A",
  },
  {
    id: "chengni-001",
    catalogNumber: "YT-2024-004",
    name: "澄泥砚·竹梅双清",
    englishName: "Chengni Inkstone — Bamboo and Plum Blossoms",
    dynasty: "唐代",
    origin: "山西绛州",
    material: "澄泥（烧制陶砚）",
    dimensions: "22 × 14 × 3.2 cm",
    description: "四大名砚中唯一陶砚，质坚如石，温润如玉",
    longDescription:
      "澄泥砚是四大名砚中唯一以陶土烧制而成的砚台，产于山西绛州。此砚以汾河细泥为原料，经过精心淘洗、成型、雕刻、烧制等多道工序制成。砚面呈温暖的赭红色，质地坚硬不亚于石砚。砚面精雕竹节与梅花图案，寓意高洁品格。澄泥砚发墨细腻，不损笔毫，储墨不干，历来为文人所珍爱。唐代诗人杜甫曾以澄泥砚作诗，留下千古佳话。",
    characteristics: ["陶土烧制", "竹梅浮雕", "不损笔毫", "储墨不干"],
    quote: "澄泥砚，质坚如石，色赭如玉，发墨不渗，储墨不干，文房至宝。",
    quoteAuthor: "米芾《砚史》",
    imageUrl:
      "https://private-us-east-1.manuscdn.com/sessionFile/0Ywg1OlIbPCyWeQ6vtOBWk/sandbox/RW6cUbJAcRnDxjcdsv8y7A-img-1_1771964453000_na1fn_Y2hlbmduaS1pbmtzdG9uZQ.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMFl3ZzFPbEliUEN5V2VRNnZ0T0JXay9zYW5kYm94L1JXNmNVYkpBY1JuRHhqY2Rzdjh5N0EtaW1nLTFfMTc3MTk2NDQ1MzAwMF9uYTFmbl9ZMmhsYm1kdWFTMXBibXR6ZEc5dVpRLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=IB9njkWrPyOwHp2ZIx1qoRyg0s1ZEiHNTIeKh~M9vplMvLYFLSoerbta0o3xl3-1i9BrJCmeyyheq~fHa3UFHXDvQYtgQrj19CP~AVvwW6pu-uSipWlQJOriVGPKIC6riM1Yi4OUYUyykSxMCo~QnKVn-lXIcoI60RqmcTTXEInpmvkDLcZX1Hj2918yJTSSxeNb-c~oO~buPePho8efwUHOUT2vtybRBiC4CKlUiW1rksg4lMcubNp~Mxfc8rZqPkvIwGSPLBrJXJXUbrvpyiNYxFu0Lg4rFzt~ImkMJK-oB17AGqz8d~W~HdwyfbIw-EQnQnpXQyxv~4Z~J~imVw__",
    accentColor: "#5A3020",
    category: "四大名砚",
    era: "唐代（618–907）",
    featured: true,
    modelColor: "#8B5A3C",
  },
];

export const historyTimeline = [
  {
    period: "先秦至汉",
    years: "前221年—220年",
    title: "砚台的起源",
    description:
      "砚台起源于新石器时代的研磨器，最初用于研磨颜料。汉代出现了专门用于研墨的砚台，材质以石、陶、铜为主。三足圆形砚是这一时期的典型形制。",
    icon: "○",
  },
  {
    period: "魏晋南北朝",
    years: "220年—589年",
    title: "瓷砚的兴起",
    description:
      "随着南方瓷业的发展，青瓷砚开始流行。砚台形制多样化，出现了辟雍砚、箕形砚等新形制。这一时期砚台开始成为文人雅士的重要文房用具。",
    icon: "◇",
  },
  {
    period: "隋唐",
    years: "581年—907年",
    title: "四大名砚确立",
    description:
      "端砚、歙砚、洮砚、澄泥砚在唐代相继被发现和使用，逐渐确立了四大名砚的地位。砚台雕刻艺术开始兴盛，文人开始在砚台上题铭。",
    icon: "◆",
  },
  {
    period: "宋代",
    years: "960年—1279年",
    title: "砚学的黄金时代",
    description:
      "宋代是中国砚台文化的鼎盛时期。苏轼、米芾、欧阳修等文豪均对砚台有深入研究，留下了大量砚铭和砚谱。砚台收藏成为文人雅事。",
    icon: "★",
  },
  {
    period: "明清",
    years: "1368年—1912年",
    title: "雕刻艺术的巅峰",
    description:
      "明清两代砚台雕刻艺术达到巅峰，题材丰富，技法精湛。宫廷御用砚台工艺极为精美，民间砚台也各具特色。砚台成为重要的艺术品和收藏品。",
    icon: "♦",
  },
  {
    period: "近现代",
    years: "1912年至今",
    title: "传承与创新",
    description:
      "砚台制作技艺被列为国家非物质文化遗产，传统工艺得到保护和传承。当代砚台艺术家在继承传统的基础上，融入现代审美，创作出兼具实用性与艺术性的砚台作品。",
    icon: "◉",
  },
];

// Additional exhibits — 历代名砚 & 文人砚
export const additionalInkstones: Inkstone[] = [
  {
    id: "songdai-001",
    catalogNumber: "YT-2024-005",
    name: "苏轼铭·天际乌云砚",
    englishName: "Su Shi Inscribed Inkstone",
    dynasty: "宋代",
    origin: "广东肇庆",
    material: "端溪坑仔岩石",
    dimensions: "18 × 12 × 2.8 cm",
    description: "苏轼亲铭，坑仔岩石质，天际乌云石品罕见",
    longDescription:
      "此砚相传为北宋大文豪苏轼所藏，砚背刻有苏轼亲笔铭文。砚石取自端溪坑仔岩，石色青灰，天然形成的乌云石品如天际云涌，极为罕见。苏轼一生爱砚，曾著有《端砚铭》等多篇砚台文章，此砚是研究苏轼文房文化的珍贵实物资料。",
    characteristics: ["苏轼亲铭", "乌云石品", "坑仔岩石质", "宋代文物"],
    quote: "石理如云，色如天际，磨墨如风，书如流水。",
    quoteAuthor: "苏轼铭文",
    imageUrl:
      "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&q=80",
    accentColor: "#2C3A4A",
    category: "历代名砚",
    era: "宋代（960–1279）",
    featured: false,
    modelColor: "#3A4A5A",
  },
  {
    id: "mingdai-001",
    catalogNumber: "YT-2024-006",
    name: "文徵明旧藏·松鹤延年砚",
    englishName: "Wen Zhengming Collection Inkstone",
    dynasty: "明代",
    origin: "安徽歙县",
    material: "歙石眉纹",
    dimensions: "25 × 18 × 4 cm",
    description: "文徵明旧藏，眉纹歙石，松鹤浮雕精美",
    longDescription:
      "此砚为明代著名书画家文徵明旧藏，砚侧有文徵明题识。砚石为歙石眉纹品种，石面天然形成的眉纹如老松虬枝，匠人据此设计，在砚边雕刻松鹤延年图案，与天然纹理相映成趣。文徵明以此砚书写了大量传世书法作品，砚台因此具有极高的历史价值和艺术价值。",
    characteristics: ["文徵明旧藏", "眉纹歙石", "松鹤浮雕", "明代题识"],
    quote: "此砚得之偶然，石纹天成，如老松苍鹤，令人爱不释手。",
    quoteAuthor: "文徵明题识",
    imageUrl:
      "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=600&q=80",
    accentColor: "#2C3A2A",
    category: "历代名砚",
    era: "明代（1368–1644）",
    featured: false,
    modelColor: "#3A4A3A",
  },
  {
    id: "qingdai-001",
    catalogNumber: "YT-2024-007",
    name: "纪晓岚铭·阅微草堂砚",
    englishName: "Ji Xiaolan Inscribed Inkstone",
    dynasty: "清代",
    origin: "甘肃洮河",
    material: "洮河绿石",
    dimensions: "30 × 20 × 5 cm",
    description: "纪晓岚铭，洮河碧绿，阅微草堂旧物",
    longDescription:
      "此砚为清代著名学者纪晓岚旧藏，砚背刻有其亲笔铭文，并注明'阅微草堂珍藏'。砚石为洮河上品绿石，色泽碧绿如翡翠，石质温润细腻。纪晓岚以此砚完成了《阅微草堂笔记》的大部分写作，是清代文学史上的重要文物。",
    characteristics: ["纪晓岚旧藏", "洮河上品", "碧绿如翡翠", "清代文物"],
    quote: "洮石碧绿，温润如玉，发墨如油，书写流畅，吾之至爱。",
    quoteAuthor: "纪晓岚铭",
    imageUrl:
      "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&q=80",
    accentColor: "#1E3A2E",
    category: "历代名砚",
    era: "清代（1644–1912）",
    featured: false,
    modelColor: "#2A5A4A",
  },
  {
    id: "wenren-001",
    catalogNumber: "YT-2024-008",
    name: "随形砚·云山意境",
    englishName: "Natural Form Inkstone — Mountain Cloud Realm",
    dynasty: "清代",
    origin: "广东肇庆",
    material: "端溪麻子坑石",
    dimensions: "不规则，约32 × 24 cm",
    description: "随形而制，云山意境，文人案头雅玩",
    longDescription:
      "此砚取材于端溪麻子坑，匠人充分利用石材的天然形态，不加过多人工雕琢，仅在砚堂处略加打磨，保留了石材原始的山形轮廓。砚面天然纹理如云山叠嶂，意境深远。这种随形砚是清代文人最为推崇的砚台形制，体现了天人合一的审美理念。",
    characteristics: ["随形天然", "麻子坑石", "云山纹理", "文人雅玩"],
    quote: "天然之石，不假雕琢，自有山水之趣，文人之砚，当如是也。",
    quoteAuthor: "清代文人题识",
    imageUrl:
      "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&q=80",
    accentColor: "#3A2A4A",
    category: "文人砚",
    era: "清代（1644–1912）",
    featured: false,
    modelColor: "#5A4A6A",
  },
];

// Merge all inkstones
inkstones.push(...additionalInkstones);
