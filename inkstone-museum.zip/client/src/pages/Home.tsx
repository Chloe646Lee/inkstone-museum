/*
 * Home Page — 砚台虚拟博物馆首页
 * Design: Immersive hero with spotlight effect, featured exhibits, museum hall preview
 * 「紫石凝英」博物馆典藏美学
 */

import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { ChevronDown, ArrowRight } from "lucide-react";
import MuseumNav from "@/components/MuseumNav";
import { inkstones, HERO_BANNER_URL, MUSEUM_HALL_URL } from "@/data/inkstones";

// Spotlight cursor effect hook
function useSpotlight(ref: React.RefObject<HTMLDivElement | null>) {
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const handleMouseMove = (e: MouseEvent) => {
      const rect = el.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      el.style.setProperty("--mouse-x", `${x}px`);
      el.style.setProperty("--mouse-y", `${y}px`);
    };
    el.addEventListener("mousemove", handleMouseMove);
    return () => el.removeEventListener("mousemove", handleMouseMove);
  }, [ref]);
}

// Intersection observer for scroll animations
function useScrollAnimation() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up");
            entry.target.classList.remove("opacity-0-init");
          }
        });
      },
      { threshold: 0.1 }
    );
    document.querySelectorAll(".scroll-animate").forEach((el) => {
      el.classList.add("opacity-0-init");
      observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);
}

export default function Home() {
  const heroRef = useRef<HTMLDivElement>(null);
  const [heroLoaded, setHeroLoaded] = useState(false);
  useSpotlight(heroRef);
  useScrollAnimation();

  const featuredInkstones = inkstones.filter((i) => i.featured);

  return (
    <div
      style={{ background: "#0F0E0C", minHeight: "100vh", color: "#EDE8DC" }}
    >
      <MuseumNav />

      {/* ── Hero Section ── */}
      <section
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
        style={{
          background: "#0F0E0C",
          cursor: "none",
        }}
      >
        {/* Background image */}
        <div className="absolute inset-0">
          <img
            src={HERO_BANNER_URL}
            alt="砚台博物馆"
            className="w-full h-full object-cover"
            style={{
              opacity: heroLoaded ? 0.45 : 0,
              transition: "opacity 1.5s ease",
            }}
            onLoad={() => setHeroLoaded(true)}
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(to bottom, rgba(15,14,12,0.3) 0%, rgba(15,14,12,0.1) 40%, rgba(15,14,12,0.7) 80%, rgba(15,14,12,1) 100%)",
            }}
          />
        </div>

        {/* Spotlight overlay */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              "radial-gradient(circle 400px at var(--mouse-x, 50%) var(--mouse-y, 50%), rgba(201, 168, 76, 0.06) 0%, transparent 70%)",
          }}
        />

        {/* Decorative corner elements */}
        <div className="absolute top-24 left-8 opacity-30">
          <div
            style={{
              width: "60px",
              height: "60px",
              borderTop: "1px solid #C9A84C",
              borderLeft: "1px solid #C9A84C",
            }}
          />
        </div>
        <div className="absolute top-24 right-8 opacity-30">
          <div
            style={{
              width: "60px",
              height: "60px",
              borderTop: "1px solid #C9A84C",
              borderRight: "1px solid #C9A84C",
            }}
          />
        </div>
        <div className="absolute bottom-24 left-8 opacity-30">
          <div
            style={{
              width: "60px",
              height: "60px",
              borderBottom: "1px solid #C9A84C",
              borderLeft: "1px solid #C9A84C",
            }}
          />
        </div>
        <div className="absolute bottom-24 right-8 opacity-30">
          <div
            style={{
              width: "60px",
              height: "60px",
              borderBottom: "1px solid #C9A84C",
              borderRight: "1px solid #C9A84C",
            }}
          />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
          <div
            className="animate-fade-in"
            style={{ animationDelay: "0.2s", opacity: 0 }}
          >
            <p
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "11px",
                letterSpacing: "0.4em",
                color: "#C9A84C",
                textTransform: "uppercase",
                marginBottom: "24px",
              }}
            >
              Virtual Museum · 虚拟博物馆
            </p>
          </div>

          <h1
            className="animate-fade-in"
            style={{
              fontFamily: "'Noto Serif SC', serif",
              fontSize: "clamp(42px, 8vw, 88px)",
              fontWeight: 300,
              letterSpacing: "0.15em",
              lineHeight: 1.1,
              color: "#EDE8DC",
              marginBottom: "8px",
              animationDelay: "0.4s",
              opacity: 0,
            }}
          >
            紫石凝英
          </h1>

          <h2
            className="animate-fade-in"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(14px, 2.5vw, 22px)",
              fontWeight: 400,
              fontStyle: "italic",
              color: "#8A8278",
              letterSpacing: "0.1em",
              marginBottom: "32px",
              animationDelay: "0.6s",
              opacity: 0,
            }}
          >
            The Art of Chinese Inkstones
          </h2>

          <div
            className="gold-divider mx-auto animate-fade-in"
            style={{
              maxWidth: "200px",
              marginBottom: "32px",
              animationDelay: "0.7s",
              opacity: 0,
            }}
          />

          <p
            className="animate-fade-in"
            style={{
              fontFamily: "'Noto Sans SC', sans-serif",
              fontSize: "15px",
              fontWeight: 300,
              color: "#B0A898",
              lineHeight: 2,
              maxWidth: "520px",
              margin: "0 auto 48px",
              animationDelay: "0.8s",
              opacity: 0,
            }}
          >
            穿越千年时光，探寻中国四大名砚的历史渊源与精湛工艺，
            感受文房至宝所承载的文化底蕴与艺术价值。
          </p>

          <div
            className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in"
            style={{ animationDelay: "1s", opacity: 0 }}
          >
            <Link href="/exhibition">
              <button
                className="group flex items-center gap-2 px-8 py-3 transition-all duration-300"
                style={{
                  background: "rgba(201, 168, 76, 0.12)",
                  border: "1px solid rgba(201, 168, 76, 0.5)",
                  color: "#C9A84C",
                  fontFamily: "'Noto Sans SC', sans-serif",
                  fontSize: "13px",
                  letterSpacing: "0.1em",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = "rgba(201, 168, 76, 0.2)";
                  e.currentTarget.style.borderColor = "#C9A84C";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background =
                    "rgba(201, 168, 76, 0.12)";
                  e.currentTarget.style.borderColor =
                    "rgba(201, 168, 76, 0.5)";
                }}
              >
                进入展览大厅
                <ArrowRight
                  size={14}
                  className="transition-transform group-hover:translate-x-1"
                />
              </button>
            </Link>
            <Link href="/history">
              <button
                className="px-8 py-3 transition-all duration-300"
                style={{
                  background: "transparent",
                  border: "1px solid rgba(176, 168, 152, 0.3)",
                  color: "#8A8278",
                  fontFamily: "'Noto Sans SC', sans-serif",
                  fontSize: "13px",
                  letterSpacing: "0.1em",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor =
                    "rgba(176, 168, 152, 0.6)";
                  e.currentTarget.style.color = "#B0A898";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor =
                    "rgba(176, 168, 152, 0.3)";
                  e.currentTarget.style.color = "#8A8278";
                }}
              >
                砚史溯源
              </button>
            </Link>
          </div>
        </div>

        {/* Scroll indicator */}
        <div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-fade-in"
          style={{ animationDelay: "1.4s", opacity: 0 }}
        >
          <span
            style={{
              fontSize: "10px",
              letterSpacing: "0.3em",
              color: "#5A5248",
              fontFamily: "'Playfair Display', serif",
            }}
          >
            SCROLL
          </span>
          <ChevronDown
            size={16}
            style={{ color: "#5A5248" }}
            className="animate-bounce"
          />
        </div>
      </section>

      {/* ── Museum Hall Preview ── */}
      <section
        className="relative py-24 overflow-hidden"
        style={{ background: "#0F0E0C" }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="scroll-animate">
              <p
                className="exhibit-label mb-4"
                style={{ color: "#8A7035" }}
              >
                Exhibition Hall · 展览大厅
              </p>
              <h2
                style={{
                  fontFamily: "'Noto Serif SC', serif",
                  fontSize: "clamp(28px, 4vw, 42px)",
                  fontWeight: 400,
                  color: "#EDE8DC",
                  lineHeight: 1.4,
                  marginBottom: "20px",
                }}
              >
                千年砚史
                <br />
                <span style={{ color: "#C9A84C" }}>典藏珍品</span>
              </h2>
              <div
                className="gold-divider mb-6"
                style={{ maxWidth: "80px" }}
              />
              <p
                style={{
                  fontFamily: "'Noto Sans SC', sans-serif",
                  fontSize: "14px",
                  fontWeight: 300,
                  color: "#8A8278",
                  lineHeight: 2,
                  marginBottom: "32px",
                }}
              >
                自唐代起，端砚、歙砚、洮砚、澄泥砚被并称为中国四大名砚，
                历经千年传承，每一方砚台都承载着独特的历史记忆与文化内涵。
                本馆精选各时代名砚珍品，为您呈现一场跨越时空的砚台艺术之旅。
              </p>
              <Link href="/exhibition">
                <button
                  className="group flex items-center gap-2 transition-all duration-300"
                  style={{
                    color: "#C9A84C",
                    fontFamily: "'Noto Sans SC', sans-serif",
                    fontSize: "13px",
                    letterSpacing: "0.1em",
                    background: "none",
                    border: "none",
                    padding: 0,
                  }}
                >
                  <span>参观展览大厅</span>
                  <ArrowRight
                    size={14}
                    className="transition-transform group-hover:translate-x-1"
                  />
                </button>
              </Link>
            </div>

            <div className="scroll-animate delay-200 relative">
              <div
                style={{
                  border: "1px solid rgba(201, 168, 76, 0.2)",
                  padding: "4px",
                }}
              >
                <img
                  src={MUSEUM_HALL_URL}
                  alt="展览大厅"
                  className="w-full"
                  style={{ display: "block", aspectRatio: "16/10", objectFit: "cover" }}
                />
              </div>
              {/* Stats overlay */}
              <div
                className="absolute bottom-8 left-8 right-8 grid grid-cols-3 gap-4"
                style={{
                  background: "rgba(15, 14, 12, 0.85)",
                  backdropFilter: "blur(8px)",
                  border: "1px solid rgba(201, 168, 76, 0.2)",
                  padding: "16px",
                }}
              >
                {[
                  { num: "4", label: "四大名砚" },
                  { num: "1300+", label: "年历史传承" },
                  { num: "12", label: "珍品展品" },
                ].map((stat) => (
                  <div key={stat.label} className="text-center">
                    <div
                      style={{
                        fontFamily: "'Playfair Display', serif",
                        fontSize: "22px",
                        color: "#C9A84C",
                        fontWeight: 600,
                      }}
                    >
                      {stat.num}
                    </div>
                    <div
                      style={{
                        fontFamily: "'Noto Sans SC', sans-serif",
                        fontSize: "11px",
                        color: "#5A5248",
                        marginTop: "2px",
                      }}
                    >
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Featured Exhibits ── */}
      <section
        className="py-24"
        style={{ background: "#0C0B09" }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="text-center mb-16 scroll-animate">
            <p className="exhibit-label mb-3" style={{ color: "#8A7035" }}>
              Featured Collection · 精选典藏
            </p>
            <h2
              style={{
                fontFamily: "'Noto Serif SC', serif",
                fontSize: "clamp(24px, 3.5vw, 36px)",
                fontWeight: 400,
                color: "#EDE8DC",
              }}
            >
              四大名砚
            </h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredInkstones.map((inkstone, index) => (
              <Link key={inkstone.id} href={`/artifact/${inkstone.id}`}>
                <div
                  className="spotlight-card group cursor-pointer"
                  style={{
                    background: "#141210",
                    border: "1px solid rgba(201, 168, 76, 0.12)",
                    animationDelay: `${index * 0.15}s`,
                  }}
                >
                  {/* Image */}
                  <div
                    className="relative overflow-hidden"
                    style={{ aspectRatio: "1/1" }}
                  >
                    <img
                      src={inkstone.imageUrl}
                      alt={inkstone.name}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div
                      className="absolute inset-0"
                      style={{
                        background:
                          "linear-gradient(to top, rgba(15,14,12,0.8) 0%, transparent 50%)",
                      }}
                    />
                    {/* Catalog number */}
                    <div
                      className="absolute top-3 right-3"
                      style={{
                        background: "rgba(15, 14, 12, 0.7)",
                        border: "1px solid rgba(201, 168, 76, 0.3)",
                        padding: "3px 8px",
                      }}
                    >
                      <span className="exhibit-label" style={{ fontSize: "9px" }}>
                        {inkstone.catalogNumber}
                      </span>
                    </div>
                    {/* Category badge */}
                    <div
                      className="absolute bottom-3 left-3"
                      style={{
                        background: "rgba(201, 168, 76, 0.15)",
                        border: "1px solid rgba(201, 168, 76, 0.3)",
                        padding: "2px 8px",
                      }}
                    >
                      <span
                        style={{
                          fontSize: "10px",
                          color: "#C9A84C",
                          fontFamily: "'Noto Sans SC', sans-serif",
                        }}
                      >
                        {inkstone.category}
                      </span>
                    </div>
                  </div>

                  {/* Info */}
                  <div className="p-4">
                    <h3
                      style={{
                        fontFamily: "'Noto Serif SC', serif",
                        fontSize: "15px",
                        fontWeight: 500,
                        color: "#EDE8DC",
                        marginBottom: "4px",
                        lineHeight: 1.4,
                      }}
                    >
                      {inkstone.name}
                    </h3>
                    <p
                      style={{
                        fontFamily: "'Playfair Display', serif",
                        fontSize: "11px",
                        color: "#5A5248",
                        fontStyle: "italic",
                        marginBottom: "10px",
                      }}
                    >
                      {inkstone.dynasty} · {inkstone.origin}
                    </p>
                    <p
                      style={{
                        fontFamily: "'Noto Sans SC', sans-serif",
                        fontSize: "12px",
                        color: "#6A6258",
                        lineHeight: 1.7,
                      }}
                    >
                      {inkstone.description}
                    </p>
                    <div
                      className="flex items-center gap-1 mt-4 group-hover:gap-2 transition-all duration-300"
                      style={{ color: "#8A7035" }}
                    >
                      <span
                        style={{
                          fontSize: "11px",
                          fontFamily: "'Noto Sans SC', sans-serif",
                        }}
                      >
                        查看详情
                      </span>
                      <ArrowRight size={11} />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── Quote Section ── */}
      <section
        className="py-24 relative"
        style={{ background: "#0F0E0C" }}
      >
        <div
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage:
              "repeating-linear-gradient(0deg, transparent, transparent 40px, rgba(201,168,76,0.3) 40px, rgba(201,168,76,0.3) 41px), repeating-linear-gradient(90deg, transparent, transparent 40px, rgba(201,168,76,0.3) 40px, rgba(201,168,76,0.3) 41px)",
          }}
        />
        <div className="max-w-3xl mx-auto px-6 text-center relative scroll-animate">
          <div
            style={{
              fontSize: "60px",
              color: "rgba(201, 168, 76, 0.2)",
              fontFamily: "'Playfair Display', serif",
              lineHeight: 1,
              marginBottom: "-20px",
            }}
          >
            "
          </div>
          <blockquote
            style={{
              fontFamily: "'Noto Serif SC', serif",
              fontSize: "clamp(16px, 2.5vw, 22px)",
              fontWeight: 300,
              color: "#B0A898",
              lineHeight: 2,
              letterSpacing: "0.05em",
              marginBottom: "24px",
            }}
          >
            砚者，研也。研墨使和濡也。
            <br />
            其制作之精，其材质之美，
            <br />
            实为文房四宝之首。
          </blockquote>
          <div
            className="gold-divider mx-auto mb-4"
            style={{ maxWidth: "60px" }}
          />
          <p
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "12px",
              color: "#5A5248",
              letterSpacing: "0.2em",
            }}
          >
            — 《说文解字》
          </p>
        </div>
      </section>

      {/* ── Craft Preview ── */}
      <section
        className="py-24"
        style={{ background: "#0C0B09" }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="scroll-animate order-2 lg:order-1 relative">
              <img
                src="https://private-us-east-1.manuscdn.com/sessionFile/0Ywg1OlIbPCyWeQ6vtOBWk/sandbox/RW6cUbJAcRnDxjcdsv8y7A-img-2_1771964453000_na1fn_aW5rc3RvbmUtY3JhZnQ.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMFl3ZzFPbEliUEN5V2VRNnZ0T0JXay9zYW5kYm94L1JXNmNVYkpBY1JuRHhqY2Rzdjh5N0EtaW1nLTJfMTc3MTk2NDQ1MzAwMF9uYTFmbl9hVzVyYzNSdmJtVXRZM0poWm5RLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=JjJl69VDt6RB7o~e-MlVJnzIqbXf8Vlm2M0JbB6VuVqvQqnp97niXYbAkUUpk7SQtvJ-iqLSrtBIYQ~E2o6bG-MTaMS~Y9bk0ijP8O3QV-ZXPuDjEoILf-aVrHEj07orrYjvvJLSSORpsw-WXxKhMHjIbXAY1fuckzNEcfjjj6D0~b~ZaERqjTJPKIuHEy9pCphlNwfMsgEs6PqM9Faf4uPVRJbjNl3Rj-k6p7E-27rXOa3XgEDV0oUIiaBSPmOlS6wyTtaJl8BB~tGJpDK7Gj1RN9BjL3KIDs8cZRVxQR~fsKtRMC-uDI-ixbmqALEJHwe8pc~-PnXkbt7hZEAM86w__"
                alt="制砚工艺"
                className="w-full"
                style={{
                  border: "1px solid rgba(201, 168, 76, 0.15)",
                  aspectRatio: "16/10",
                  objectFit: "cover",
                }}
              />
            </div>

            <div className="scroll-animate delay-200 order-1 lg:order-2">
              <p className="exhibit-label mb-4" style={{ color: "#8A7035" }}>
                Craft & Heritage · 制砚工艺
              </p>
              <h2
                style={{
                  fontFamily: "'Noto Serif SC', serif",
                  fontSize: "clamp(28px, 4vw, 42px)",
                  fontWeight: 400,
                  color: "#EDE8DC",
                  lineHeight: 1.4,
                  marginBottom: "20px",
                }}
              >
                匠心独运
                <br />
                <span style={{ color: "#C9A84C" }}>千年技艺</span>
              </h2>
              <div
                className="gold-divider mb-6"
                style={{ maxWidth: "80px" }}
              />
              <p
                style={{
                  fontFamily: "'Noto Sans SC', sans-serif",
                  fontSize: "14px",
                  fontWeight: 300,
                  color: "#8A8278",
                  lineHeight: 2,
                  marginBottom: "32px",
                }}
              >
                砚台制作是一门融合选材、设计、雕刻、打磨于一体的综合艺术。
                从山间采石到案头珍品，每一方砚台都凝聚着匠人数十年的心血与技艺，
                传承着中华文明最精粹的工艺智慧。
              </p>
              <Link href="/craft">
                <button
                  className="group flex items-center gap-2 transition-all duration-300"
                  style={{
                    color: "#C9A84C",
                    fontFamily: "'Noto Sans SC', sans-serif",
                    fontSize: "13px",
                    letterSpacing: "0.1em",
                    background: "none",
                    border: "none",
                    padding: 0,
                  }}
                >
                  <span>了解制砚工艺</span>
                  <ArrowRight
                    size={14}
                    className="transition-transform group-hover:translate-x-1"
                  />
                </button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer
        style={{
          background: "#080706",
          borderTop: "1px solid rgba(201, 168, 76, 0.1)",
          padding: "40px 0",
        }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div
                style={{
                  width: "28px",
                  height: "28px",
                  border: "1px solid rgba(201, 168, 76, 0.4)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <span
                  style={{
                    fontFamily: "'Noto Serif SC', serif",
                    color: "#C9A84C",
                    fontSize: "12px",
                  }}
                >
                  砚
                </span>
              </div>
              <span
                style={{
                  fontFamily: "'Noto Serif SC', serif",
                  fontSize: "13px",
                  color: "#5A5248",
                }}
              >
                砚台虚拟博物馆
              </span>
            </div>
            <p
              style={{
                fontFamily: "'Noto Sans SC', sans-serif",
                fontSize: "12px",
                color: "#3A3530",
              }}
            >
              © 2024 砚台虚拟博物馆 · 传承千年砚文化
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
