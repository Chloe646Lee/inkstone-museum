/*
 * Craft — 制砚工艺页面
 * Design: Step-by-step craft process with rich imagery
 * 「紫石凝英」博物馆典藏美学
 */

import { useEffect } from "react";
import MuseumNav from "@/components/MuseumNav";
import { CRAFT_URL } from "@/data/inkstones";

const craftSteps = [
  {
    step: "01",
    title: "选石采料",
    subtitle: "Stone Selection",
    desc: "制砚的第一步是选石。砚石的质量直接决定砚台的品质。以端砚为例，采石工人需深入端溪山洞，凭借丰富经验辨别石质优劣。好的砚石质地细腻、温润如玉，叩之声音清脆。",
    detail:
      "采石是一项危险而艰辛的工作。端溪老坑位于地下深处，采石工人需在狭窄的洞穴中工作，用传统工具小心翼翼地开凿，以免损伤珍贵的石材。每块砚石都是大自然数亿年的馈赠。",
  },
  {
    step: "02",
    title: "锯料设计",
    subtitle: "Cutting & Design",
    desc: "选好石料后，工匠需根据石材的形状、纹理和石品（如鱼脑冻、青花等）进行构思设计。好的设计能最大限度地展现石材的天然之美，同时兼顾实用功能。",
    detail:
      "设计是制砚中最需要创意和经验的环节。工匠需要像雕塑家一样，在脑海中构建砚台的最终形态，然后用墨线在石料上描绘出轮廓。",
  },
  {
    step: "03",
    title: "雕刻纹饰",
    subtitle: "Carving & Decoration",
    desc: "雕刻是制砚工艺中最具艺术价值的环节。工匠使用各种专用雕刻刀，在砚台边缘雕刻出龙凤、山水、花鸟等传统纹饰。刀法要求遒劲有力，线条流畅自然。",
    detail:
      "一方精品砚台的雕刻往往需要数月乃至数年的时间。工匠需要具备深厚的绘画功底和精湛的雕刻技艺，才能将设计图稿转化为立体的艺术作品。",
  },
  {
    step: "04",
    title: "打磨抛光",
    subtitle: "Grinding & Polishing",
    desc: "雕刻完成后，需要对砚台进行精细打磨。工匠使用从粗到细的不同砂纸，将砚面打磨至光滑细腻。砚堂（研墨区域）需要特别处理，既要细腻又要有一定的摩擦力以利于发墨。",
    detail:
      "打磨是一个耗时耗力的过程，需要工匠极大的耐心。砚台的不同部位需要不同程度的打磨：砚堂需要细腻但有磨擦感，砚边需要光滑圆润，雕刻部分则需要保留适当的粗糙感。",
  },
  {
    step: "05",
    title: "题铭落款",
    subtitle: "Inscription",
    desc: "高档砚台往往会请著名书法家或文人在砚背或砚侧题写铭文，内容多为诗词、警句或对砚台的赞美之词。题铭不仅增加了砚台的文化价值，也是砚台身份的重要标志。",
    detail:
      "历史上许多著名文人如苏轼、米芾、纪晓岚等都曾为砚台题铭，这些题铭砚台如今已成为珍贵的文物，兼具书法艺术和砚台艺术的双重价值。",
  },
  {
    step: "06",
    title: "配匣收藏",
    subtitle: "Storage Box",
    desc: "精品砚台通常配有专门定制的砚匣（砚盒）。砚匣多以红木、紫檀等名贵木材制成，内衬丝绒，外刻精美图案。砚匣不仅保护砚台，本身也是一件精美的工艺品。",
    detail:
      "砚匣的制作同样需要高超的工艺。木工需要根据砚台的形状精确制作，使砚台与砚匣完美契合。上好的砚匣能有效防止砚台受潮、碰撞，延长砚台的使用寿命。",
  },
];

export default function Craft() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("craft-visible");
          }
        });
      },
      { threshold: 0.1 }
    );
    document.querySelectorAll(".craft-item").forEach((el) => {
      observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <div
      style={{ background: "#0F0E0C", minHeight: "100vh", color: "#EDE8DC" }}
    >
      <style>{`
        .craft-item {
          opacity: 0;
          transform: translateY(20px);
          transition: opacity 0.7s ease, transform 0.7s ease;
        }
        .craft-item.craft-visible {
          opacity: 1;
          transform: translateY(0);
        }
      `}</style>

      <MuseumNav />

      {/* Hero */}
      <section className="relative overflow-hidden" style={{ height: "60vh", minHeight: "400px", paddingTop: "64px" }}>
        <img
          src={CRAFT_URL}
          alt="制砚工艺"
          className="absolute inset-0 w-full h-full object-cover"
          style={{ opacity: 0.5 }}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(to bottom, rgba(15,14,12,0.4) 0%, rgba(15,14,12,0.6) 50%, rgba(15,14,12,1) 100%)",
          }}
        />
        <div className="absolute inset-0 flex items-end">
          <div className="max-w-7xl mx-auto px-6 lg:px-10 pb-16 w-full">
            <p className="exhibit-label mb-3" style={{ color: "#8A7035" }}>
              Craft & Heritage · 制砚工艺
            </p>
            <h1
              style={{
                fontFamily: "'Noto Serif SC', serif",
                fontSize: "clamp(32px, 5vw, 56px)",
                fontWeight: 400,
                color: "#EDE8DC",
                marginBottom: "12px",
              }}
            >
              匠心制砚
            </h1>
            <p
              style={{
                fontFamily: "'Noto Sans SC', sans-serif",
                fontSize: "14px",
                color: "#6A6258",
                maxWidth: "480px",
                lineHeight: 1.8,
              }}
            >
              一方砚台的诞生，凝聚了采石、设计、雕刻、打磨等数十道工序，
              每一步都需要匠人倾注心血与智慧。
            </p>
          </div>
        </div>
      </section>

      {/* Craft Steps */}
      <section className="py-20">
        <div className="max-w-5xl mx-auto px-6 lg:px-10">
          <div className="space-y-0">
            {craftSteps.map((step, index) => {
              const isEven = index % 2 === 0;
              return (
                <div
                  key={step.step}
                  className="craft-item grid md:grid-cols-2 gap-0"
                  style={{
                    borderBottom: "1px solid rgba(201, 168, 76, 0.08)",
                    transitionDelay: `${index * 0.1}s`,
                  }}
                >
                  {/* Step number side */}
                  <div
                    className={`p-8 lg:p-12 flex flex-col justify-center ${isEven ? "" : "md:order-2"}`}
                    style={{
                      background: isEven
                        ? "rgba(201, 168, 76, 0.03)"
                        : "transparent",
                      borderRight: isEven
                        ? "1px solid rgba(201, 168, 76, 0.08)"
                        : "none",
                      borderLeft: !isEven
                        ? "1px solid rgba(201, 168, 76, 0.08)"
                        : "none",
                    }}
                  >
                    <div className="flex items-start gap-6">
                      <div
                        style={{
                          fontFamily: "'Playfair Display', serif",
                          fontSize: "56px",
                          fontWeight: 600,
                          color: "rgba(201, 168, 76, 0.12)",
                          lineHeight: 1,
                          minWidth: "70px",
                        }}
                      >
                        {step.step}
                      </div>
                      <div>
                        <h3
                          style={{
                            fontFamily: "'Noto Serif SC', serif",
                            fontSize: "22px",
                            fontWeight: 500,
                            color: "#EDE8DC",
                            marginBottom: "4px",
                          }}
                        >
                          {step.title}
                        </h3>
                        <p
                          style={{
                            fontFamily: "'Playfair Display', serif",
                            fontSize: "12px",
                            color: "#8A7035",
                            fontStyle: "italic",
                            letterSpacing: "0.1em",
                            marginBottom: "16px",
                          }}
                        >
                          {step.subtitle}
                        </p>
                        <p
                          style={{
                            fontFamily: "'Noto Sans SC', sans-serif",
                            fontSize: "13px",
                            fontWeight: 300,
                            color: "#8A8278",
                            lineHeight: 2,
                          }}
                        >
                          {step.desc}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Detail side */}
                  <div
                    className={`p-8 lg:p-12 flex flex-col justify-center ${!isEven ? "md:order-1" : ""}`}
                  >
                    <div
                      className="p-6"
                      style={{
                        background: "rgba(201, 168, 76, 0.03)",
                        border: "1px solid rgba(201, 168, 76, 0.1)",
                        borderLeft: "3px solid rgba(201, 168, 76, 0.3)",
                      }}
                    >
                      <p
                        style={{
                          fontFamily: "'Noto Sans SC', sans-serif",
                          fontSize: "13px",
                          fontWeight: 300,
                          color: "#6A6258",
                          lineHeight: 2.1,
                        }}
                      >
                        {step.detail}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Master Craftsmen */}
      <section
        className="py-20"
        style={{
          background: "#0C0B09",
          borderTop: "1px solid rgba(201, 168, 76, 0.08)",
        }}
      >
        <div className="max-w-5xl mx-auto px-6 lg:px-10">
          <div className="text-center mb-12">
            <p className="exhibit-label mb-3" style={{ color: "#8A7035" }}>
              Master Craftsmen · 制砚名家
            </p>
            <h2
              style={{
                fontFamily: "'Noto Serif SC', serif",
                fontSize: "clamp(22px, 3vw, 32px)",
                fontWeight: 400,
                color: "#EDE8DC",
              }}
            >
              砚台艺术传承人
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {[
              {
                name: "黎铿",
                title: "中国工艺美术大师",
                specialty: "端砚",
                desc: "当代端砚艺术的代表人物，作品融合传统技艺与现代审美，多件作品被国家博物馆收藏。",
              },
              {
                name: "方见尘",
                title: "国家级非遗传承人",
                specialty: "歙砚",
                desc: "歙砚制作技艺国家级非物质文化遗产传承人，致力于歙砚传统技艺的保护与传承。",
              },
              {
                name: "卢进桥",
                title: "中国工艺美术大师",
                specialty: "端砚",
                desc: "以精湛的雕刻技艺著称，善于在砚台上表现山水意境，作品具有极高的艺术价值。",
              },
              {
                name: "蔺永茂",
                title: "甘肃省工艺美术大师",
                specialty: "洮砚",
                desc: "洮砚制作技艺传承人，深入研究洮砚历史与工艺，为洮砚的推广与传承做出重要贡献。",
              },
            ].map((master) => (
              <div
                key={master.name}
                className="craft-item p-6"
                style={{
                  background: "#141210",
                  border: "1px solid rgba(201, 168, 76, 0.1)",
                }}
              >
                <div className="flex items-start gap-4">
                  <div
                    style={{
                      width: "48px",
                      height: "48px",
                      background: "rgba(201, 168, 76, 0.08)",
                      border: "1px solid rgba(201, 168, 76, 0.2)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    <span
                      style={{
                        fontFamily: "'Noto Serif SC', serif",
                        fontSize: "16px",
                        color: "#C9A84C",
                      }}
                    >
                      {master.name[0]}
                    </span>
                  </div>
                  <div>
                    <h4
                      style={{
                        fontFamily: "'Noto Serif SC', serif",
                        fontSize: "16px",
                        color: "#EDE8DC",
                        marginBottom: "2px",
                      }}
                    >
                      {master.name}
                    </h4>
                    <p
                      style={{
                        fontSize: "11px",
                        color: "#C9A84C",
                        fontFamily: "'Noto Sans SC', sans-serif",
                        marginBottom: "2px",
                      }}
                    >
                      {master.title}
                    </p>
                    <p
                      style={{
                        fontSize: "11px",
                        color: "#5A5248",
                        fontFamily: "'Noto Sans SC', sans-serif",
                        marginBottom: "10px",
                      }}
                    >
                      专长：{master.specialty}
                    </p>
                    <p
                      style={{
                        fontFamily: "'Noto Sans SC', sans-serif",
                        fontSize: "13px",
                        color: "#6A6258",
                        lineHeight: 1.8,
                      }}
                    >
                      {master.desc}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer
        style={{
          background: "#080706",
          borderTop: "1px solid rgba(201, 168, 76, 0.1)",
          padding: "32px 0",
        }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-10 text-center">
          <p
            style={{
              fontFamily: "'Noto Sans SC', sans-serif",
              fontSize: "12px",
              color: "#3A3530",
            }}
          >
            © 2024 砚台虚拟博物馆 · 传承千年砚文化
          </p>
        </div>
      </footer>
    </div>
  );
}
