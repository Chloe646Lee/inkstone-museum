/*
 * ExhibitionHall — 展览大厅页面
 * Design: Museum gallery grid with spotlight hover effects
 * 「紫石凝英」博物馆典藏美学
 */

import { useEffect, useState } from "react";
import { Link } from "wouter";
import { ArrowRight, Search } from "lucide-react";
import MuseumNav from "@/components/MuseumNav";
import { inkstones, MUSEUM_HALL_URL } from "@/data/inkstones";

export default function ExhibitionHall() {
  const [activeFilter, setActiveFilter] = useState<string>("全部");
  const [searchQuery, setSearchQuery] = useState("");
  const [visibleItems, setVisibleItems] = useState<Set<string>>(new Set());

  const filters = ["全部", "四大名砚", "历代名砚", "文人砚"];

  const filteredInkstones = inkstones.filter((inkstone) => {
    const matchFilter =
      activeFilter === "全部" || inkstone.category === activeFilter;
    const matchSearch =
      !searchQuery ||
      inkstone.name.includes(searchQuery) ||
      inkstone.origin.includes(searchQuery) ||
      inkstone.dynasty.includes(searchQuery);
    return matchFilter && matchSearch;
  });

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleItems((prev) => { const next = new Set(prev); next.add(entry.target.id); return next; });
          }
        });
      },
      { threshold: 0.1 }
    );
    document.querySelectorAll(".exhibit-item").forEach((el) => {
      observer.observe(el);
    });
    return () => observer.disconnect();
  }, [filteredInkstones]);

  return (
    <div style={{ background: "#0F0E0C", minHeight: "100vh", color: "#EDE8DC" }}>
      <MuseumNav />

      {/* Page Header */}
      <section
        className="relative pt-32 pb-16 overflow-hidden"
        style={{ background: "#0C0B09" }}
      >
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage: `url(${MUSEUM_HALL_URL})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            filter: "blur(2px)",
          }}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(to bottom, rgba(12,11,9,0.7), rgba(12,11,9,0.95))",
          }}
        />
        <div className="relative max-w-7xl mx-auto px-6 lg:px-10">
          <p
            className="exhibit-label mb-3"
            style={{ color: "#8A7035" }}
          >
            Exhibition Hall · 展览大厅
          </p>
          <h1
            style={{
              fontFamily: "'Noto Serif SC', serif",
              fontSize: "clamp(32px, 5vw, 52px)",
              fontWeight: 400,
              color: "#EDE8DC",
              marginBottom: "12px",
            }}
          >
            典藏展览
          </h1>
          <p
            style={{
              fontFamily: "'Noto Sans SC', sans-serif",
              fontSize: "14px",
              color: "#6A6258",
              maxWidth: "500px",
              lineHeight: 1.8,
            }}
          >
            本馆收藏历代砚台珍品，涵盖端砚、歙砚、洮砚、澄泥砚四大名砚及历代名家用砚，
            每件展品均附有详细的历史背景与文化解读。
          </p>
        </div>
      </section>

      {/* Filters & Search */}
      <section
        style={{
          background: "#0F0E0C",
          borderBottom: "1px solid rgba(201, 168, 76, 0.1)",
          position: "sticky",
          top: "64px",
          zIndex: 40,
        }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-10 py-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            {/* Filter tabs */}
            <div className="flex items-center gap-1">
              {filters.map((filter) => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className="px-4 py-2 transition-all duration-200"
                  style={{
                    fontFamily: "'Noto Sans SC', sans-serif",
                    fontSize: "12px",
                    letterSpacing: "0.05em",
                    background:
                      activeFilter === filter
                        ? "rgba(201, 168, 76, 0.15)"
                        : "transparent",
                    border:
                      activeFilter === filter
                        ? "1px solid rgba(201, 168, 76, 0.4)"
                        : "1px solid transparent",
                    color: activeFilter === filter ? "#C9A84C" : "#5A5248",
                  }}
                >
                  {filter}
                </button>
              ))}
            </div>

            {/* Search */}
            <div
              className="flex items-center gap-2 px-3 py-2"
              style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(201, 168, 76, 0.15)",
                minWidth: "200px",
              }}
            >
              <Search size={13} style={{ color: "#5A5248" }} />
              <input
                type="text"
                placeholder="搜索砚台..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  background: "transparent",
                  border: "none",
                  outline: "none",
                  color: "#B0A898",
                  fontFamily: "'Noto Sans SC', sans-serif",
                  fontSize: "12px",
                  width: "100%",
                }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Exhibition Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredInkstones.map((inkstone, index) => (
              <Link key={inkstone.id} href={`/artifact/${inkstone.id}`}>
                <div
                  id={`exhibit-${inkstone.id}`}
                  className="exhibit-item spotlight-card group cursor-pointer"
                  style={{
                    background: "#141210",
                    border: "1px solid rgba(201, 168, 76, 0.1)",
                    opacity: visibleItems.has(`exhibit-${inkstone.id}`) ? 1 : 0,
                    transform: visibleItems.has(`exhibit-${inkstone.id}`)
                      ? "translateY(0)"
                      : "translateY(20px)",
                    transition: `opacity 0.6s ease ${index * 0.1}s, transform 0.6s ease ${index * 0.1}s`,
                  }}
                >
                  {/* Image */}
                  <div
                    className="relative overflow-hidden"
                    style={{ aspectRatio: "1/1" }}
                  >
                    <img
                      src={inkstone.imageUrl}
                      alt={inkstone.name}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div
                      className="absolute inset-0"
                      style={{
                        background:
                          "linear-gradient(to top, rgba(15,14,12,0.9) 0%, transparent 60%)",
                      }}
                    />
                    {/* Catalog number */}
                    <div
                      className="absolute top-3 left-3"
                      style={{
                        background: "rgba(15, 14, 12, 0.8)",
                        border: "1px solid rgba(201, 168, 76, 0.25)",
                        padding: "2px 8px",
                      }}
                    >
                      <span
                        className="exhibit-label"
                        style={{ fontSize: "9px" }}
                      >
                        {inkstone.catalogNumber}
                      </span>
                    </div>
                    {/* Era badge */}
                    <div className="absolute bottom-3 left-3 right-3">
                      <div
                        style={{
                          background: "rgba(201, 168, 76, 0.1)",
                          border: "1px solid rgba(201, 168, 76, 0.2)",
                          padding: "2px 8px",
                          display: "inline-block",
                        }}
                      >
                        <span
                          style={{
                            fontSize: "10px",
                            color: "#C9A84C",
                            fontFamily: "'Noto Sans SC', sans-serif",
                          }}
                        >
                          {inkstone.dynasty}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Info */}
                  <div className="p-4">
                    <h3
                      style={{
                        fontFamily: "'Noto Serif SC', serif",
                        fontSize: "15px",
                        fontWeight: 500,
                        color: "#EDE8DC",
                        marginBottom: "4px",
                      }}
                    >
                      {inkstone.name}
                    </h3>
                    <p
                      style={{
                        fontFamily: "'Noto Sans SC', sans-serif",
                        fontSize: "11px",
                        color: "#5A5248",
                        marginBottom: "8px",
                      }}
                    >
                      {inkstone.origin} · {inkstone.material}
                    </p>
                    <p
                      style={{
                        fontFamily: "'Noto Sans SC', sans-serif",
                        fontSize: "12px",
                        color: "#6A6258",
                        lineHeight: 1.7,
                        marginBottom: "12px",
                      }}
                    >
                      {inkstone.description}
                    </p>

                    {/* Characteristics */}
                    <div className="flex flex-wrap gap-1 mb-3">
                      {inkstone.characteristics.slice(0, 2).map((c) => (
                        <span
                          key={c}
                          style={{
                            fontSize: "10px",
                            color: "#5A5248",
                            background: "rgba(255,255,255,0.03)",
                            border: "1px solid rgba(201, 168, 76, 0.1)",
                            padding: "1px 6px",
                            fontFamily: "'Noto Sans SC', sans-serif",
                          }}
                        >
                          {c}
                        </span>
                      ))}
                    </div>

                    <div
                      className="flex items-center gap-1 group-hover:gap-2 transition-all duration-300"
                      style={{ color: "#8A7035" }}
                    >
                      <span
                        style={{
                          fontSize: "11px",
                          fontFamily: "'Noto Sans SC', sans-serif",
                        }}
                      >
                        查看详情
                      </span>
                      <ArrowRight size={11} />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {filteredInkstones.length === 0 && (
            <div className="text-center py-24">
              <p
                style={{
                  fontFamily: "'Noto Serif SC', serif",
                  fontSize: "16px",
                  color: "#3A3530",
                }}
              >
                未找到相关展品
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer
        style={{
          background: "#080706",
          borderTop: "1px solid rgba(201, 168, 76, 0.1)",
          padding: "32px 0",
        }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-10 text-center">
          <p
            style={{
              fontFamily: "'Noto Sans SC', sans-serif",
              fontSize: "12px",
              color: "#3A3530",
            }}
          >
            © 2024 砚台虚拟博物馆 · 传承千年砚文化
          </p>
        </div>
      </footer>
    </div>
  );
}
