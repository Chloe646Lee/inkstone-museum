/*
 * ArtifactDetail — 砚台详情展示页
 * Design: Full-screen immersive exhibit view with spotlight effect + 3D viewer
 * 「紫石凝英」博物馆典藏美学
 */

import { useEffect, useRef, useState } from "react";
import { Link, useParams } from "wouter";
import { ArrowLeft, ChevronRight } from "lucide-react";
import MuseumNav from "@/components/MuseumNav";
import InkstoneViewer3D from "@/components/InkstoneViewer3D";
import InkstoneInfoPanel from "@/components/InkstoneInfoPanel";
import FavoriteShareButtons from "@/components/FavoriteShareButtons";
import { useFavorites } from "@/hooks/useFavorites";
import { inkstones } from "@/data/inkstones";

export default function ArtifactDetail() {
  const params = useParams<{ id: string }>();
  const inkstone = inkstones.find((i) => i.id === params.id);
  const imageRef = useRef<HTMLDivElement>(null);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [activeTab, setActiveTab] = useState<"info" | "quote" | "chars" | "3d">(
    "info"
  );
  const { isFavorite, toggleFavorite, isLoaded } = useFavorites();

  // 3D tilt effect on image
  useEffect(() => {
    const el = imageRef.current;
    if (!el) return;
    const handleMouseMove = (e: MouseEvent) => {
      const rect = el.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      el.style.transform = `perspective(1000px) rotateY(${x * 8}deg) rotateX(${-y * 8}deg)`;
    };
    const handleMouseLeave = () => {
      el.style.transform =
        "perspective(1000px) rotateY(0deg) rotateX(0deg)";
    };
    el.addEventListener("mousemove", handleMouseMove);
    el.addEventListener("mouseleave", handleMouseLeave);
    return () => {
      el.removeEventListener("mousemove", handleMouseMove);
      el.removeEventListener("mouseleave", handleMouseLeave);
    };
  }, []);

  if (!inkstone) {
    return (
      <div
        style={{
          background: "#0F0E0C",
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "#5A5248",
          fontFamily: "'Noto Serif SC', serif",
        }}
      >
        <div className="text-center">
          <p style={{ fontSize: "18px", marginBottom: "16px" }}>展品未找到</p>
          <Link href="/exhibition">
            <span style={{ color: "#C9A84C", fontSize: "14px" }}>
              返回展览大厅
            </span>
          </Link>
        </div>
      </div>
    );
  }

  // Related inkstones
  const related = inkstones
    .filter((i) => i.id !== inkstone.id && i.category === inkstone.category)
    .slice(0, 3);

  return (
    <div
      style={{ background: "#0F0E0C", minHeight: "100vh", color: "#EDE8DC" }}
    >
      <MuseumNav />

      {/* Breadcrumb */}
      <div
        className="pt-20 pb-4"
        style={{ borderBottom: "1px solid rgba(201, 168, 76, 0.08)" }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="flex items-center gap-2">
            <Link href="/">
              <span
                style={{
                  fontSize: "12px",
                  color: "#5A5248",
                  fontFamily: "'Noto Sans SC', sans-serif",
                  cursor: "pointer",
                }}
                className="hover:text-[#8A8278] transition-colors"
              >
                首页
              </span>
            </Link>
            <ChevronRight size={12} style={{ color: "#3A3530" }} />
            <Link href="/exhibition">
              <span
                style={{
                  fontSize: "12px",
                  color: "#5A5248",
                  fontFamily: "'Noto Sans SC', sans-serif",
                  cursor: "pointer",
                }}
                className="hover:text-[#8A8278] transition-colors"
              >
                展览大厅
              </span>
            </Link>
            <ChevronRight size={12} style={{ color: "#3A3530" }} />
            <span
              style={{
                fontSize: "12px",
                color: "#8A8278",
                fontFamily: "'Noto Sans SC', sans-serif",
              }}
            >
              {inkstone.name}
            </span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            {/* Left: Image with 3D effect / 3D Viewer */}
            <div>
              {activeTab === "3d" ? (
                <InkstoneViewer3D
                  inkstoneId={inkstone.id}
                  inkstoneColor={inkstone.modelColor}
                />
              ) : (
                <div
                  ref={imageRef}
                  className="relative"
                  style={{
                    transition: "transform 0.1s ease",
                    transformStyle: "preserve-3d",
                  }}
                >
                  {/* Outer frame */}
                  <div
                    style={{
                      padding: "8px",
                      background: "#141210",
                      border: "1px solid rgba(201, 168, 76, 0.25)",
                      boxShadow:
                        "0 20px 60px rgba(0,0,0,0.6), 0 0 40px rgba(201,168,76,0.05)",
                    }}
                  >
                    <img
                      src={inkstone.imageUrl}
                      alt={inkstone.name}
                      className="w-full"
                      style={{
                        display: "block",
                        aspectRatio: "1/1",
                        objectFit: "cover",
                        opacity: imageLoaded ? 1 : 0,
                        transition: "opacity 0.8s ease",
                      }}
                      onLoad={() => setImageLoaded(true)}
                    />
                  </div>

                  {/* Spotlight overlay */}
                  <div
                    className="absolute inset-0 pointer-events-none"
                    style={{
                      background:
                        "radial-gradient(ellipse 60% 40% at 50% 30%, rgba(201,168,76,0.06) 0%, transparent 70%)",
                    }}
                  />

                  {/* Catalog tag */}
                  {(activeTab === "info" || activeTab === "chars" || activeTab === "quote") && (
                    <div
                      className="absolute -bottom-4 left-8"
                      style={{
                        background: "#141210",
                        border: "1px solid rgba(201, 168, 76, 0.3)",
                        padding: "8px 16px",
                      }}
                    >
                      <p
                        className="exhibit-label"
                        style={{ fontSize: "10px", marginBottom: "2px" }}
                      >
                        Catalog No.
                      </p>
                      <p
                        style={{
                          fontFamily: "'Courier New', monospace",
                          fontSize: "13px",
                          color: "#C9A84C",
                        }}
                      >
                        {inkstone.catalogNumber}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* 3D 查看器下方的信息面板 */}
              {activeTab === "3d" && <InkstoneInfoPanel inkstone={inkstone} />}

              {/* Dimensions */}
              {activeTab !== "3d" && (
                <div
                  className="mt-10 p-4"
                  style={{
                    background: "rgba(201, 168, 76, 0.04)",
                    border: "1px solid rgba(201, 168, 76, 0.1)",
                  }}
                >
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { label: "尺寸", value: inkstone.dimensions },
                      { label: "材质", value: inkstone.material },
                      { label: "年代", value: inkstone.dynasty },
                    ].map((item) => (
                      <div key={item.label} className="text-center">
                        <p
                          className="exhibit-label mb-1"
                          style={{ fontSize: "9px" }}
                        >
                          {item.label}
                        </p>
                        <p
                          style={{
                            fontFamily: "'Noto Sans SC', sans-serif",
                            fontSize: "12px",
                            color: "#B0A898",
                          }}
                      >
                        {item.value}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
              )}
            </div>
            {/* Right: Information */}
            <div>
              <div className="mb-2">
                <span
                  style={{
                    background: "rgba(201, 168, 76, 0.1)",
                    border: "1px solid rgba(201, 168, 76, 0.25)",
                    padding: "3px 10px",
                    fontSize: "11px",
                    color: "#C9A84C",
                    fontFamily: "'Noto Sans SC', sans-serif",
                  }}
                >
                  {inkstone.category}
                </span>
              </div>

              <h1
                style={{
                  fontFamily: "'Noto Serif SC', serif",
                  fontSize: "clamp(28px, 4vw, 42px)",
                  fontWeight: 400,
                  color: "#EDE8DC",
                  lineHeight: 1.3,
                  marginBottom: "8px",
                  marginTop: "12px",
                }}
              >
                {inkstone.name}
              </h1>

              <p
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "16px",
                  color: "#5A5248",
                  fontStyle: "italic",
                  marginBottom: "4px",
                }}
              >
                {inkstone.englishName}
              </p>

              <p
                style={{
                  fontFamily: "'Noto Sans SC', sans-serif",
                  fontSize: "13px",
                  color: "#5A5248",
                  marginBottom: "24px",
                }}
              >
                {inkstone.era} · {inkstone.origin}
              </p>

              <div
                className="gold-divider mb-6"
                style={{ maxWidth: "100px" }}
              />

              {/* Favorite and Share Buttons */}
              {isLoaded && (
                <div className="mb-8">
                  <FavoriteShareButtons
                    inkstone={inkstone}
                    isFavorite={isFavorite(inkstone.id)}
                    onToggleFavorite={() => toggleFavorite(inkstone.id)}
                  />
                </div>
              )}

              {/* Tab Navigation */}
              <div
                className="flex gap-0 mb-6 overflow-x-auto"
                style={{ borderBottom: "1px solid rgba(201, 168, 76, 0.1)" }}
              >
                {(
                  [
                    { key: "info", label: "展品介绍" },
                    { key: "chars", label: "石品特征" },
                    { key: "quote", label: "历代题铭" },
                    { key: "3d", label: "360° 展示" },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    style={{
                      padding: "12px 20px",
                      background: "transparent",
                      border: "none",
                      borderBottom:
                        activeTab === tab.key
                          ? "2px solid #C9A84C"
                          : "2px solid transparent",
                      color: activeTab === tab.key ? "#C9A84C" : "#5A5248",
                      fontFamily: "'Noto Sans SC', sans-serif",
                      fontSize: "13px",
                      cursor: "pointer",
                      transition: "all 0.3s ease",
                      whiteSpace: "nowrap",
                    }}
                    className="hover:text-[#8A8278]"
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Tab Content */}
              <div style={{ minHeight: "300px" }}>
                {activeTab === "info" && (
                  <div>
                    <p
                      style={{
                        fontFamily: "'Noto Sans SC', sans-serif",
                        fontSize: "14px",
                        lineHeight: 1.8,
                        color: "#B0A898",
                        marginBottom: "16px",
                      }}
                    >
                      {inkstone.description}
                    </p>
                    <p
                      style={{
                        fontFamily: "'Noto Sans SC', sans-serif",
                        fontSize: "13px",
                        lineHeight: 1.8,
                        color: "#8A8278",
                      }}
                    >
                      {inkstone.longDescription}
                    </p>
                  </div>
                )}

                {activeTab === "chars" && (
                  <div>
                    <p
                      style={{
                        fontFamily: "'Noto Sans SC', sans-serif",
                        fontSize: "13px",
                        color: "#5A5248",
                        marginBottom: "12px",
                      }}
                    >
                      此砚具有以下特征：
                    </p>
                    <div className="space-y-3">
                      {inkstone.characteristics.map((char, idx) => (
                        <div
                          key={idx}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "12px",
                          }}
                        >
                          <span
                            style={{
                              width: "6px",
                              height: "6px",
                              background: "#C9A84C",
                              borderRadius: "50%",
                              flexShrink: 0,
                            }}
                          />
                          <span
                            style={{
                              fontFamily: "'Noto Sans SC', sans-serif",
                              fontSize: "13px",
                              color: "#B0A898",
                            }}
                          >
                            {char}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

              {activeTab === "quote" && (
                  <div
                    style={{
                      borderLeft: "3px solid rgba(201, 168, 76, 0.3)",
                      paddingLeft: "16px",
                      paddingTop: "8px",
                      paddingBottom: "8px",
                    }}
                  >
                    <p
                      style={{
                        fontFamily: "'Noto Serif SC', serif",
                        fontSize: "15px",
                        lineHeight: 1.8,
                        color: "#C9A84C",
                        fontStyle: "italic",
                        marginBottom: "12px",
                      }}
                    >
                      "{inkstone.quote}"
                    </p>
                    <p
                      style={{
                        fontFamily: "'Noto Sans SC', sans-serif",
                        fontSize: "12px",
                        color: "#5A5248",
                        textAlign: "right",
                      }}
                    >
                      —— {inkstone.quoteAuthor}
                    </p>
                  </div>
                )}

                {activeTab === "3d" && (
                  <div style={{ color: "#8A8278", fontSize: "13px" }}>
                    <p>
                      在左侧查看此砚台的 3D 模型，支持以下交互方式：
                    </p>
                    <ul style={{ marginTop: "12px", paddingLeft: "20px" }}>
                      <li>• 鼠标拖拽：360° 旋转查看砚台</li>
                      <li>• 滚轮：放大或缩小模型</li>
                      <li>• 自动旋转：停止拖拽后自动旋转</li>
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Related Exhibits */}
      {related.length > 0 && (
        <section
          className="py-16"
          style={{
            borderTop: "1px solid rgba(201, 168, 76, 0.08)",
            background: "rgba(20, 18, 16, 0.5)",
          }}
        >
          <div className="max-w-7xl mx-auto px-6 lg:px-10">
            <h2
              style={{
                fontFamily: "'Noto Serif SC', serif",
                fontSize: "24px",
                fontWeight: 400,
                color: "#EDE8DC",
                marginBottom: "32px",
              }}
            >
              相关展品
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              {related.map((item) => (
                <Link key={item.id} href={`/artifact/${item.id}`}>
                  <div
                    className="spotlight-card group cursor-pointer"
                    style={{
                      background: "rgba(30, 28, 24, 0.8)",
                      border: "1px solid rgba(201, 168, 76, 0.15)",
                      padding: "16px",
                      transition: "all 0.3s ease",
                    }}
                  >
                    <div
                      style={{
                        aspectRatio: "1/1",
                        background: "#141210",
                        marginBottom: "12px",
                        overflow: "hidden",
                      }}
                    >
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <p
                      className="exhibit-label mb-2"
                      style={{ fontSize: "9px" }}
                    >
                      {item.era}
                    </p>
                    <h3
                      style={{
                        fontFamily: "'Noto Serif SC', serif",
                        fontSize: "15px",
                        color: "#EDE8DC",
                        marginBottom: "4px",
                      }}
                    >
                      {item.name}
                    </h3>
                    <p
                      style={{
                        fontFamily: "'Noto Sans SC', sans-serif",
                        fontSize: "12px",
                        color: "#5A5248",
                      }}
                    >
                      {item.origin}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
