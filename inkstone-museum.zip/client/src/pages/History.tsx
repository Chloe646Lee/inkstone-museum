/*
 * History — 砚史溯源页面
 * Design: Timeline narrative with scroll animations
 * 「紫石凝英」博物馆典藏美学
 */

import { useEffect, useRef } from "react";
import MuseumNav from "@/components/MuseumNav";
import { historyTimeline } from "@/data/inkstones";

export default function History() {
  const timelineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("timeline-visible");
          }
        });
      },
      { threshold: 0.15 }
    );
    document.querySelectorAll(".timeline-item").forEach((el) => {
      observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <div
      style={{ background: "#0F0E0C", minHeight: "100vh", color: "#EDE8DC" }}
    >
      <style>{`
        .timeline-item {
          opacity: 0;
          transform: translateX(-30px);
          transition: opacity 0.7s ease, transform 0.7s ease;
        }
        .timeline-item.timeline-visible {
          opacity: 1;
          transform: translateX(0);
        }
        .timeline-item:nth-child(even) {
          transform: translateX(30px);
        }
        .timeline-item:nth-child(even).timeline-visible {
          transform: translateX(0);
        }
      `}</style>

      <MuseumNav />

      {/* Page Header */}
      <section
        className="pt-32 pb-16"
        style={{
          background:
            "linear-gradient(to bottom, #0C0B09, #0F0E0C)",
          borderBottom: "1px solid rgba(201, 168, 76, 0.1)",
        }}
      >
        <div className="max-w-4xl mx-auto px-6 lg:px-10 text-center">
          <p
            className="exhibit-label mb-4"
            style={{ color: "#8A7035" }}
          >
            History & Origins · 砚史溯源
          </p>
          <h1
            style={{
              fontFamily: "'Noto Serif SC', serif",
              fontSize: "clamp(32px, 5vw, 52px)",
              fontWeight: 400,
              color: "#EDE8DC",
              marginBottom: "16px",
            }}
          >
            砚台千年史
          </h1>
          <div
            className="gold-divider mx-auto mb-8"
            style={{ maxWidth: "80px" }}
          />
          <p
            style={{
              fontFamily: "'Noto Sans SC', sans-serif",
              fontSize: "15px",
              fontWeight: 300,
              color: "#6A6258",
              lineHeight: 2,
              maxWidth: "600px",
              margin: "0 auto",
            }}
          >
            砚台的历史，是中国书写文化的缩影。
            从新石器时代的研磨器，到文人案头的珍玩，
            砚台见证了中华文明数千年的演进与传承。
          </p>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20" ref={timelineRef}>
        <div className="max-w-5xl mx-auto px-6 lg:px-10">
          {/* Central line */}
          <div className="relative">
            <div
              className="absolute left-1/2 top-0 bottom-0 w-px -translate-x-1/2"
              style={{
                background:
                  "linear-gradient(to bottom, transparent, rgba(201, 168, 76, 0.3), rgba(201, 168, 76, 0.3), transparent)",
              }}
            />

            <div className="space-y-0">
              {historyTimeline.map((item, index) => {
                const isEven = index % 2 === 0;
                return (
                  <div
                    key={item.period}
                    className="timeline-item relative grid grid-cols-2 gap-8 items-center"
                    style={{ minHeight: "180px" }}
                  >
                    {/* Left content (even) or empty (odd) */}
                    <div
                      className={`${isEven ? "text-right pr-8" : "order-2 pl-8 text-left"}`}
                    >
                      {isEven ? (
                        <TimelineContent item={item} />
                      ) : (
                        <div />
                      )}
                    </div>

                    {/* Center node */}
                    <div
                      className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10"
                      style={{ width: "48px", textAlign: "center" }}
                    >
                      <div
                        style={{
                          width: "40px",
                          height: "40px",
                          background: "#141210",
                          border: "1px solid rgba(201, 168, 76, 0.4)",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          margin: "0 auto",
                        }}
                      >
                        <span
                          style={{
                            fontSize: "16px",
                            color: "#C9A84C",
                          }}
                        >
                          {item.icon}
                        </span>
                      </div>
                    </div>

                    {/* Right content (odd) or empty (even) */}
                    <div
                      className={`${!isEven ? "text-left pl-8" : "order-2 pr-8 text-right"}`}
                    >
                      {!isEven ? (
                        <TimelineContent item={item} />
                      ) : (
                        <div />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Mobile Timeline (single column) */}
      <section className="py-8 md:hidden">
        <div className="max-w-lg mx-auto px-6">
          {historyTimeline.map((item) => (
            <div
              key={item.period}
              className="relative pl-12 pb-12"
              style={{ borderLeft: "1px solid rgba(201, 168, 76, 0.2)" }}
            >
              <div
                className="absolute left-0 top-0 -translate-x-1/2"
                style={{
                  width: "32px",
                  height: "32px",
                  background: "#141210",
                  border: "1px solid rgba(201, 168, 76, 0.4)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <span style={{ fontSize: "14px", color: "#C9A84C" }}>
                  {item.icon}
                </span>
              </div>
              <TimelineContent item={item} />
            </div>
          ))}
        </div>
      </section>

      {/* Cultural Significance */}
      <section
        className="py-20"
        style={{
          background: "#0C0B09",
          borderTop: "1px solid rgba(201, 168, 76, 0.08)",
        }}
      >
        <div className="max-w-4xl mx-auto px-6 lg:px-10">
          <div className="text-center mb-12">
            <p className="exhibit-label mb-3" style={{ color: "#8A7035" }}>
              Cultural Significance · 文化意义
            </p>
            <h2
              style={{
                fontFamily: "'Noto Serif SC', serif",
                fontSize: "clamp(22px, 3vw, 32px)",
                fontWeight: 400,
                color: "#EDE8DC",
              }}
            >
              砚台与文房文化
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                title: "文房四宝",
                subtitle: "Four Treasures of the Study",
                desc: "砚台与笔、墨、纸并称文房四宝，是中国传统书写文化的核心器具，承载着文人的精神世界与审美追求。",
                icon: "筆",
              },
              {
                title: "文人雅趣",
                subtitle: "Scholar's Aesthetic",
                desc: "历代文人不仅将砚台作为实用工具，更视之为艺术品加以收藏品鉴。题砚铭、作砚谱，形成了独特的砚台文化。",
                icon: "墨",
              },
              {
                title: "非遗传承",
                subtitle: "Intangible Heritage",
                desc: "端砚、歙砚等制作技艺已被列为国家级非物质文化遗产，传承人们以毕生心血守护这份珍贵的文化遗产。",
                icon: "砚",
              },
            ].map((card) => (
              <div
                key={card.title}
                className="p-6"
                style={{
                  background: "#141210",
                  border: "1px solid rgba(201, 168, 76, 0.1)",
                }}
              >
                <div
                  style={{
                    width: "44px",
                    height: "44px",
                    background: "rgba(201, 168, 76, 0.08)",
                    border: "1px solid rgba(201, 168, 76, 0.2)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: "16px",
                  }}
                >
                  <span
                    style={{
                      fontFamily: "'Noto Serif SC', serif",
                      fontSize: "18px",
                      color: "#C9A84C",
                    }}
                  >
                    {card.icon}
                  </span>
                </div>
                <h3
                  style={{
                    fontFamily: "'Noto Serif SC', serif",
                    fontSize: "16px",
                    color: "#EDE8DC",
                    marginBottom: "4px",
                  }}
                >
                  {card.title}
                </h3>
                <p
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "11px",
                    color: "#5A5248",
                    fontStyle: "italic",
                    marginBottom: "12px",
                  }}
                >
                  {card.subtitle}
                </p>
                <p
                  style={{
                    fontFamily: "'Noto Sans SC', sans-serif",
                    fontSize: "13px",
                    color: "#6A6258",
                    lineHeight: 1.9,
                  }}
                >
                  {card.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer
        style={{
          background: "#080706",
          borderTop: "1px solid rgba(201, 168, 76, 0.1)",
          padding: "32px 0",
        }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-10 text-center">
          <p
            style={{
              fontFamily: "'Noto Sans SC', sans-serif",
              fontSize: "12px",
              color: "#3A3530",
            }}
          >
            © 2024 砚台虚拟博物馆 · 传承千年砚文化
          </p>
        </div>
      </footer>
    </div>
  );
}

function TimelineContent({
  item,
}: {
  item: (typeof historyTimeline)[0];
}) {
  return (
    <div>
      <p
        style={{
          fontFamily: "'Playfair Display', serif",
          fontSize: "11px",
          color: "#8A7035",
          letterSpacing: "0.2em",
          marginBottom: "4px",
        }}
      >
        {item.years}
      </p>
      <h3
        style={{
          fontFamily: "'Noto Serif SC', serif",
          fontSize: "18px",
          fontWeight: 500,
          color: "#EDE8DC",
          marginBottom: "4px",
        }}
      >
        {item.period}
      </h3>
      <p
        style={{
          fontFamily: "'Noto Serif SC', serif",
          fontSize: "14px",
          color: "#C9A84C",
          marginBottom: "10px",
        }}
      >
        {item.title}
      </p>
      <p
        style={{
          fontFamily: "'Noto Sans SC', sans-serif",
          fontSize: "13px",
          fontWeight: 300,
          color: "#6A6258",
          lineHeight: 1.9,
          maxWidth: "340px",
        }}
      >
        {item.description}
      </p>
    </div>
  );
}
